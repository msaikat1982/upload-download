# Azure Bicep Modules

This code repository holds the Bicep modules used by GEHA Platform team. 
These modules are hosted in an Azure Container Registry named "gehabicep".

![GEHABicepModulesDiagram](docs/Bicep_IaC_Diagram.png "Bicep_IaC_Diagram")

## Contributing

If you would like to change/update an existing template, or add a new template:
1. Clone the repo to your development machine.
2. Create a new branch with a descriptive name such as "feat/keyvault-module"
3. For any _new_ module:
    * Add _folder/module.bicep_ under the /modules folder
    * Add _folder/module-template.bicep_ under the /templates folder
    * Add the module to the strategy matrix in azure-pipelines.yml
    * Add the module to the version table shown below
        * Also update the version table if you modify an existing module
4. Test your module locally by pointing your template to _../../modules/folder/module.bicep_ and running an AZ Cli deployment, similar to:

**az deployment group create --resource-group YOUR-RG-NAME --template-file _templates/folder/module-template.bicep_**

5. Once your test is complete, point your template to the instance of your module in ACR and push your branch up to ADO
6. Create a Pull Request from your branch to the main branch. Review your changes, add your work item, and submit your PR for review
7. Once your changes are approved and merged into main, manually create a git tag. The new tag will trigger the deployment pipeline and publish the module to ACR with your new tag. <br>
    * The new Git tag **must** follow this convention: **_modulename/v{new version number}_** <br>
    * If you are iterating module keyvault/v2.0.0, the Git new tag would be: **keyvault/v2.0.1**

## How to Use These Bicep Modules

In your bicep deployment files, you will reference the Bicep modules hosted in ACR.
example:
```bash
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module stgacct 'br:gehabicep.azurecr.io/bicep/modules/storageaccount:v0.1.4' = {
  name: 'test-${deploymentTimeStamp}'
  params: {
    name: 'testbicepstgacct'
  }
}
```
Deploy Bicep Code:

```bash
 az deployment group what-if --resource-group YOUR-RG-NAME --template-file test.bicep
 az deployment group create --resource-group YOUR-RG-NAME --template-file test.bicep
 ```

## Note: Versions 3.0.0 and above allow for creation of a Private Endpoint by passing a value to the 'subnetId' parameter (where applicable).