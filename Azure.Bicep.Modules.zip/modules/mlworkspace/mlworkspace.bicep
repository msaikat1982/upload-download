
////////////////////////
// Default Parameters //
////////////////////////

@description('Azure Region for deployment')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Azure resource tags provided as key/value object')
param tags object = {}

/////////////////////////
// Resource Parameters //
/////////////////////////

@description('AI Studio/AML name')
param name string

@allowed([
  'hub'
  'Default'
])
@description('Kind of workspace to deploy - Default/Hub')
param kind string

@description('AI Studio/AML display name')
param friendlyName string = name

@description('AI Studio/AML description')
param amlDescription string = 'Azure Machine Learning Workspace'

////////////////////////////////////
// Resource Dependency Parameters //
////////////////////////////////////

@description('AI services name')
param aiServicesName string = ''

@description('Key Vault name')
param keyVaultName string

@description('Storage Account name')
param strgAcctName string

@description('Application Insights name')
param appInsightsName string

@description('Container Registry name')
param acrName string

@allowed([
  'Disabled'
])
@description('Should Public Network Access be enabled for this AI Services account.')
param publicNetworkAccess string = 'Disabled'


///////////////////////////////////
// Existing Resources References //
///////////////////////////////////


resource aiServices 'Microsoft.CognitiveServices/accounts@2023-05-01' existing = if(!(empty(aiServicesName))) {
  name: aiServicesName
}

resource kv 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
  name: keyVaultName
}

resource strg 'Microsoft.Storage/storageAccounts@2023-05-01' existing = {
  name: strgAcctName
}

resource appi 'Microsoft.Insights/components@2020-02-02' existing = {
  name: appInsightsName
}

resource acr 'Microsoft.ContainerRegistry/registries@2023-01-01-preview' existing = {
  name: acrName
}

///////////////////
// Resource Call //
///////////////////

resource aml_aistudio 'Microsoft.MachineLearningServices/workspaces@2024-07-01-preview' = {
  name: name
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    publicNetworkAccess: publicNetworkAccess
    // organization
    friendlyName: friendlyName
    description: amlDescription

    // dependent resources
    keyVault: kv.id
    storageAccount: strg.id
    applicationInsights: appi.id
    containerRegistry: acr.id

    // allow outbound
    managedNetwork: {
      isolationMode: 'AllowInternetOutbound'
      status: {
        status: 'Active'
      }
    }
  }
  kind: kind

  resource aiServicesConnection 'connections@2024-01-01-preview' = if(!(empty(aiServicesName))) {
    name: '${name}-connection-AzureOpenAI'
    properties: {
      category: 'AzureOpenAI'
      target: aiServices.properties.endpoint
      authType: 'ApiKey'
      isSharedToAll: true
      credentials: {
        key: aiServices.listKeys().key1
      }
      metadata: {
        ApiType: 'Azure'
        ResourceId: aiServices.id
      }
    }
  }
}

output amlAiStudioId string = aml_aistudio.id
output amlAiStuidoMSI string = aml_aistudio.identity.principalId

// Compute instance...

resource compute 'Microsoft.MachineLearningServices/workspaces/computes@2024-01-01-preview' = {
  parent: aml_aistudio
  name: 'platform-${uniqueString(aml_aistudio.name)}'
  location: location
  properties: {    
    disableLocalAuth: true
    computeLocation: location
    computeType: 'ComputeInstance'
    properties: {
      vmSize: 'Standard_DS1_v2'
      idleTimeBeforeShutdown: 'PT15M'
    }
  }
}

// Private Endpoints...

param subnetId string

// @sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
// var dnsZoneConfig = {
//   amlapi: {
//     groupId: 'amlworkspace'
//     privateDnsZone: 'privatelink.api.azureml.ms'
//   }
//   amlNotebooks: {
//     groupId: 'amlworkspace'
//     privateDnsZone: 'privatelink.notebooks.azure.net'
//   }
// }

// Module call to create Private Endpoints and Private Endpoint DNS for AI Studio and AML...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module amlSrvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = if (!empty(subnetId)) {
  name: '${aml_aistudio.name}-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: aml_aistudio.id
    pvtEpName: '${aml_aistudio.name}-pvtep'
    location: location
    groupdId: 'amlworkspace'
    privateDnsZones: [
      'privatelink.api.azureml.ms'
      'privatelink.notebooks.azure.net'
    ]
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

// Create Diagnostic Settings for AI Studio/AML - Send logs to central log analytics workspace
@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'
resource aml_aiStudioDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${aml_aistudio.name}-diag'
  scope: aml_aistudio
  properties: {
    // logAnalyticsDestinationType: null
    workspaceId: defaultLogAnalyticsWorkspaceId
    metrics: []
    logs: [
      {
        category: null
        categoryGroup: 'audit'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: null
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
  }
}
