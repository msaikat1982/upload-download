param mlworkspaceName string
param serviceResourceName string
param serviceResourceId string
param resourceTargetType string

resource mlworkspace 'Microsoft.MachineLearningServices/workspaces@2023-10-01' existing = {
  name: mlworkspaceName
}

resource amlOutboundRules 'Microsoft.MachineLearningServices/workspaces/outboundRules@2023-10-01' =  {
  name: '${serviceResourceName}-${resourceTargetType}'
  parent: mlworkspace
  properties: {
    category: 'UserDefined'
    status: 'Active'
    type: 'PrivateEndpoint'
    destination: {
      serviceResourceId: serviceResourceId
      sparkEnabled: false
      sparkStatus: 'Inactive'
      subresourceTarget: resourceTargetType
    }
  }
}
