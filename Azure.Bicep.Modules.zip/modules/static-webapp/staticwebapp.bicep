@description('Required. The name of the static site.')
@minLength(1)
@maxLength(40)
param name string

@description('Location for swa resource.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Location for swa private endpoint resource.')
param pelocation string = resourceGroup().location

@description('Azure resource tags provided as key/value object.')
param tags object = {}

@allowed([
  'Free'
  'Standard'
])
@description('Optional. The service tier and name of the resource SKU.')
param sku string = 'Standard'

@description('Optional. False if config file is locked for this static web app; otherwise, true.')
param allowConfigFileUpdates bool = true

@allowed([
  'Enabled'
  'Disabled'
])
@description('Optional. State indicating whether staging environments are allowed or not allowed for a static web app.')
param stagingEnvironmentPolicy string = 'Enabled'


@allowed([
  'Disabled'
  'Enabled'
])
@description('Optional. State indicating the status of the enterprise grade CDN serving traffic to the static web app.')
param enterpriseGradeCdnStatus string = 'Disabled'

@allowed([
  'Disabled'
])
param publicNetworkAccess string = 'Disabled'

@description('The identity type of the App Service.')
param identityType string = 'SystemAssigned'

resource staticWebApp 'Microsoft.Web/staticSites@2024-04-01' = {
  name: name
  location: location
  tags: tags
  identity: {
    type: identityType
  }
  properties: {
    publicNetworkAccess: publicNetworkAccess
    allowConfigFileUpdates: allowConfigFileUpdates
    stagingEnvironmentPolicy: stagingEnvironmentPolicy
    enterpriseGradeCdnStatus: enterpriseGradeCdnStatus
  }
  sku: {
    name: sku
    tier: sku
  }
}

output staticWebAppUrl string = staticWebApp.properties.defaultHostname

//Private Endpoints...

param subnetId string = ''

// @sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
// var dnsZoneConfig = {
//   app: {
//     groupId: 'sites'
//     privateDnsZone: 'privatelink.azurewebsites.net'
//   }
//   appscm: {
//     groupId: 'sites'
//     privateDnsZone: 'scm.privatelink.azurewebsites.net'
//   }
// }

// Module call to create Private Endpoints and Private Endpoint DNS for App service...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module appSrvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'swa-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: staticWebApp.id
    pvtEpName: '${staticWebApp.name}-pvtep'
    location: pelocation
    groupdId: 'staticSites'
    privateDnsZone: 'privatelink.${substring(staticWebApp.properties.defaultHostname,indexOf(staticWebApp.properties.defaultHostname,'.')+1,(length(staticWebApp.properties.defaultHostname)-(indexOf(staticWebApp.properties.defaultHostname, '.')+1)))}'
  }
}
