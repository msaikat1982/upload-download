// https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces/topics/subscriptions?pivots=deployment-language-bicep#sbsubscriptionproperties

param serviceBusNamespace string

resource servicebusnamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespace
}

param topicName string
resource topic 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' existing = {
  name: topicName
  parent: servicebusnamespace
}

param subscriptionName string
param autoDeleteOnIdle string = 'P10675198DT2H48M5.477S' // Never
param defaultMessageTimeToLive string = 'P14D' // 14 Days
param duplicateDetectionHistoryTimeWindow string = 'PT10M' // 10 minutes
param lockDuration string = 'PT1M' // 1 minute
param maxDeliveryCount int = 10
param enableBatchedOperations bool = true
param deadLetteringOnFilterEvaluationExceptions bool = false
param deadLetteringOnMessageExpiration bool = false
param requiresSession bool = false
param status string = 'Active'
// param forwardDeadLetteredMessagesTo string = ''
// param forwardTo string = ''
// param isClientAffine bool = false
// param clientId string = ''
// param isDurable bool = false
// param isShared bool = false

resource subscription 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2022-10-01-preview' = {
  name: subscriptionName
  parent: topic
  properties: {
    autoDeleteOnIdle: autoDeleteOnIdle
    defaultMessageTimeToLive: defaultMessageTimeToLive
    duplicateDetectionHistoryTimeWindow: duplicateDetectionHistoryTimeWindow
    lockDuration: lockDuration
    maxDeliveryCount: maxDeliveryCount
    enableBatchedOperations: enableBatchedOperations
    deadLetteringOnFilterEvaluationExceptions: deadLetteringOnFilterEvaluationExceptions
    deadLetteringOnMessageExpiration: deadLetteringOnMessageExpiration
    requiresSession: requiresSession
    status: status
    // forwardDeadLetteredMessagesTo: forwardDeadLetteredMessagesTo
    // forwardTo: forwardTo
    // isClientAffine: isClientAffine
    // clientAffineProperties: {
    // clientId: clientId
    // isDurable: isDurable
    // isShared: isShared
    // }
  }
}

output subscriptionName string = subscription.name
output subscriptionId string = subscription.id
