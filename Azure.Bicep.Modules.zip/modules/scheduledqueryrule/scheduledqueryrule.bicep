param alertRuleDetails object

resource logAnalyticsWorkspace 'Microsoft.OperationalInsights/workspaces@2025-02-01' existing = {
  scope: resourceGroup(alertRuleDetails.logAnalyticsWorkspaceSubId, alertRuleDetails.logAnalyticsWorkspaceRg)
  name: alertRuleDetails.logAnalyticsWorkspaceName
}

resource actionGroup 'Microsoft.Insights/actionGroups@2024-10-01-preview' existing = {
  name: alertRuleDetails.actionGroupName
}

resource logAlertRule 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  dependsOn: [logAnalyticsWorkspace, actionGroup]
  name: alertRuleDetails.alertRuleName
  location: alertRuleDetails.logAnalyticsWorkspaceLocation // Or a specific region if required for data residency
  kind: alertRuleDetails.kind
  properties: {
    description: alertRuleDetails.description
    displayName: alertRuleDetails.displayName
    enabled: true
    evaluationFrequency: alertRuleDetails.evaluationFrequency
    windowSize: alertRuleDetails.windowSize
    scopes: [
      logAnalyticsWorkspace.id
    ]
    criteria: {
      allOf: [
        {
          query: alertRuleDetails.kustoQuery
          timeAggregation: alertRuleDetails.timeAggregation // or Total?
          operator: alertRuleDetails.operator
          threshold: alertRuleDetails.threshold
        }
      ]
    }
    actions: {
      actionGroups: [
        actionGroup.id
      ]
    }
    severity: alertRuleDetails.severity // 0=Critical, 1=Error, 2=Warning, 3=Informational, 4=Verbose
    autoMitigate: alertRuleDetails.autoMitigate// Automatically resolve the alert when the condition is no longer met
    }
}
