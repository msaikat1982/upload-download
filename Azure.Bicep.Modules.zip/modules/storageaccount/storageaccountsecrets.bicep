param accessKey bool
param connectionString bool
param storageAccountName string
param keyvaultName string

// reference existing storage account...
resource storageaccountReference 'Microsoft.Storage/storageAccounts@2022-09-01' existing = {
  name: storageAccountName
}

// reference existing keyvault...
resource keyvaultReference 'Microsoft.KeyVault/vaults@2024-11-01' existing = {
  name: keyvaultName
}

// storage account connection string as secret'...
resource connStr 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = if (connectionString) {
  name: 'strg-acct-conn-str-${storageaccountReference.name}'
  parent: keyvaultReference
  properties: {
    value: 'DefaultEndpointsProtocol=https;AccountName=${storageaccountReference.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storageaccountReference.listKeys().keys[0].value}'
  }
}

// storage account access key as secret'...
resource accKey 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = if (accessKey) {
  name: 'strg-acct-key-${storageaccountReference.name}'
  parent: keyvaultReference
  properties: {
    value: storageaccountReference.listKeys().keys[0].value
  }
}
