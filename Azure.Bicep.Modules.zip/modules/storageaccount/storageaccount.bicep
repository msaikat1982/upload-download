@minLength(3)
@maxLength(24)
@description('Name of Storage Account')
param storageAccountName string
var stAccountName = toLower(storageAccountName)

@description('Azure Region to deploy Storage Account')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Environment for Storage Account')
@allowed(['poc','dev','tst','stg','prd'])
param env string

@description('Access tier for Storage Account')
@allowed(['Cool','Hot','Premium'])
param accessTier string = 'Hot'

@description('''
Enable hierarchical namespace on blob storage
Commonly enabled for Data Lake type storage 
''')
param hnsEnabled bool = false

@allowed([
  'Standard_ZRS'
])
@description('Storage SKU')
param storageSkuName string = 'Standard_ZRS'

param publicNetworkAccess string = 'Disabled'

@description('Map [env] to an Azure resource tag')
var envMap = {
  poc: 'poc'
  dev: 'Develop'
  tst: 'Test'
  stg: 'Stage'
  prd: 'Production'
}
var envTag = envMap[env]
var tag = {Environment: envTag}

@description('Azure resource tags provided as key/value object')
param tags object = {}

//Storage Account...
resource storageAccount 'Microsoft.Storage/storageAccounts@2022-09-01' = {
  name: stAccountName
  location: location
  tags: union(tag,tags)
  sku: {
    name: storageSkuName
  }
  kind: 'StorageV2'
  properties: {
    allowCrossTenantReplication: true
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    allowSharedKeyAccess: true
    networkAcls: {
      bypass: 'AzureServices'
      virtualNetworkRules: []
      ipRules: []
      defaultAction: 'Allow'
    }
    supportsHttpsTrafficOnly: true
    accessTier: accessTier
    isHnsEnabled: hnsEnabled
    publicNetworkAccess: publicNetworkAccess
  }
}

//Blob Service...
@description('Enable or disable blob deletion retention policy (soft-delete)')
param deleteRetentionPolicyEnabled bool = false

@description('Enable or disable blob versioning')
param isBlobVersioningEnabled bool = false

@description('Permanent delete enables you to permanently delete a soft-deleted snapshot or blob version before the retention period ends. Default is false.')
param allowPermanentDelete bool = true
param blobDeletionRetentionDays int = 14

@description('Enable or disable blob deletion retention policy (soft-delete)')
param containerDeleteRetentionPolicyEnabled bool = false
param containerDeletionRetentionDays int = 14

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2022-09-01' = {
  name: 'default'
  parent: storageAccount
  properties: {
    deleteRetentionPolicy: {
      enabled: deleteRetentionPolicyEnabled
      allowPermanentDelete: allowPermanentDelete
      days: blobDeletionRetentionDays
    }
    containerDeleteRetentionPolicy: {
      enabled: containerDeleteRetentionPolicyEnabled
      days: containerDeletionRetentionDays
    }
    isVersioningEnabled: isBlobVersioningEnabled
  }
}

//Blob containers...
param containerNames array = []

resource containers 'Microsoft.Storage/storageAccounts/blobServices/containers@2021-06-01' = [for containerName in containerNames: {
  parent: blobService
  name: !empty(containerNames) ? '${toLower(containerName)}' : 'placeholder'
  properties: {
    publicAccess: 'None'
    metadata: {}
  }
}]

//Private Endpoints...

param subnetId string

@sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
var dnsZoneConfig = {
  blob: {
    groupId: 'Blob'
    privateDnsZone: 'privatelink.blob.core.windows.net'
  }
  file: {
    groupId: 'File'
    privateDnsZone: 'privatelink.file.core.windows.net'
  }
  queue: {
    groupId: 'queue'
    privateDnsZone: 'privatelink.queue.core.windows.net'
  }
  table: {
    groupId: 'table'
    privateDnsZone: 'privatelink.table.core.windows.net'
  }
  dfs: {
    groupId: 'dfs'
    privateDnsZone: 'privatelink.dfs.core.windows.net'
  }
}

// Module call to create Private Endpoints and Private Endpoint DNS for storage types...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module stPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = [for zone in items(dnsZoneConfig): if (!empty(subnetId)) {
  name: '${storageAccountName}-PvtEp-${zone.value.groupId}-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: storageAccount.id
    pvtEpName: '${storageAccount.name}-${zone.value.groupId}-pvtep'
    location: location
    groupdId: zone.value.groupId
    privateDnsZone: zone.value.privateDnsZone
  }
}]

// output the name and the id of the Storage Account resource once it has been created...
output storageAccountResourceName string = storageAccount.name
output storageAccountResourceId string = storageAccount.id

// store access key or connection string in key vault...

@description('Bool: put the storage account access key in your keyvault?')
param storeAccessKey bool = false

@description('Bool: put the storage account connection string in your keyvault?')
param storeConnectionString bool = false

@description('The key vault for storing storage account access info.')
param keyvault string = ''

module storageaccountkey 'br:gehabicep.azurecr.io/bicep/modules/storageaccountsecrets:v1.0.1' = if (storeAccessKey || storeConnectionString) {
  name: 'strg-acct-key-${storageAccount.name}-${deploymentTimeStamp}'
  params: {
    accessKey: storeAccessKey
    connectionString: storeConnectionString
    storageAccountName: storageAccount.name
    keyvaultName: keyvault
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

param streamDiagsToEventHub bool = false

var eventHubNamespaceMap = {
  centralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-c-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  eastus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-e-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  northcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Ops0-DCRG/providers/Microsoft.EventHub/namespaces/net0-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
  southcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/OPS1-DCRG/providers/Microsoft.EventHub/namespaces/net1-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
}

@description('Based on location of Service Bus, use eventHub in that region.')
var eventHubRuleId = eventHubNamespaceMap[location]

@description('Map eventHubName namespace to the eventHub name within the namespace')
var eventHubNameMap = {
  centralus: 'insights-operational-logs'
  eastus: 'insights-operational-logs'
  northcentralus: 'insights-operational-logs'
  southcentralus: 'insights-operational-logs'
}

@description('Get the Event Hub name from the appropriate namespace')
var eventHubName = eventHubNameMap[location]

resource serviceBusDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = if (streamDiagsToEventHub) {
  name: '${storageAccount.name}-blob-diag'
  scope: blobService
  properties: {
    eventHubAuthorizationRuleId: eventHubRuleId
    eventHubName: eventHubName
    logs: [
      {
        category: 'StorageRead'
        enabled: true
        retentionPolicy: {
          enabled: false
          days: 0
        }
      }
      {
        category: 'StorageWrite'
        enabled: true
        retentionPolicy: {
          enabled: false
          days: 0
        }
      }
      {
        category: 'StorageDelete'
        enabled: true
        retentionPolicy: {
          enabled: false
          days: 0
        }
      }
    ]
    metrics: [
      {
        category: 'Transaction'
        enabled: true
        retentionPolicy: {
          enabled: false
          days: 0
        }
      }
    ]
  }
}
