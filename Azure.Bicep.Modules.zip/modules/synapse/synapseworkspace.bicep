////////////////////////
// Default Parameters //
////////////////////////

@description('Azure Region for deployment')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Azure resource tags provided as key/value object')
param tags object = {}

/////////////////////////
// Resource Parameters //
/////////////////////////

@description('Name of the Synapse Workspace')
@maxLength(50)
param synapseWorkspaceName string

@description('Construct the dataLakeStorageAccountUrl property value')
param workspaceDataLakeAccountName string 
var storageEnvironmentDNS = environment().suffixes.storage
var dataLakeStorageAccountUrl = 'https://${workspaceDataLakeAccountName}.dfs.${storageEnvironmentDNS}'

@description('The ID of the default ADLS en 2 account used by Synapse')
param defaultDataLakeStorageResourceId string

@description('The name of the "default" filesystem container for Synapse')
param synapseDefaultContainerName string = 'synapseroot' //https://stackoverflow.com/questions/75554592/should-you-use-the-primary-storage-of-azure-synapse-as-your-data-lake

// param sqlAdministratorLogin string
// @secure()
// param sqlAdministratorLoginPassword string

@description('The resource ID of the tenant Purview account')
param purviewId string = '/subscriptions/59e2fd5d-7f2a-4631-a012-d30803c8017f/resourceGroups/rg-governance-mgt/providers/Microsoft.Purview/accounts/purview-geha-prd'

@description('Synapse workspace Git configuration')
param workspaceRepositoryConfiguration object = {}

///////////////////
// Resource Call //
///////////////////

resource synapseWorkspace 'Microsoft.Synapse/workspaces@2021-06-01' = {
  name: synapseWorkspaceName
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
    //userAssignedIdentities: {}
  }
  properties: {
    azureADOnlyAuthentication: false //https://learn.microsoft.com/en-us/azure/azure-sql/database/authentication-azure-ad-only-authentication?view=azuresql&tabs=azure-cli
    // We found that this setting does nothing even if set and used on the initial deployment. 
    // To set the Entra admin, see the Microsoft.Synapse/workspaces/administrators@2021-06-01 resource in this module.
    // cspWorkspaceAdminProperties: {
    //   initialWorkspaceAdminObjectId: 'string' //https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/active-directory-authentication#disable-local-authentication
    // }
    defaultDataLakeStorage: {
      accountUrl: dataLakeStorageAccountUrl
      createManagedPrivateEndpoint: true
      filesystem: synapseDefaultContainerName
      resourceId: defaultDataLakeStorageResourceId
    }
    // encryption: {
    //   cmk: {
    //     kekIdentity: {
    //       userAssignedIdentity: 'string'
    //       useSystemAssignedIdentity: any()
    //     }
    //     key: {
    //       keyVaultUrl: 'string'
    //       name: 'string'
    //     }
    //   }
    // }
    managedResourceGroupName: 'rg-managed-${synapseWorkspaceName}'
    managedVirtualNetwork: 'default'
    managedVirtualNetworkSettings: {
      // allowedAadTenantIdsForLinking: [
      //   'string'
      // ]
      // linkedAccessCheckOnTargetResource: bool
      preventDataExfiltration: false
    }
    // privateEndpointConnections: [
    //   {
    //     properties: {
    //       privateEndpoint: {}
    //       privateLinkServiceConnectionState: {
    //         description: 'string'
    //         status: 'string'
    //       }
    //     }
    //   }
    // ]
    publicNetworkAccess: 'Disabled'
    purviewConfiguration: {
      purviewResourceId: purviewId
    }
    // sqlAdministratorLogin: sqlAdministratorLogin
    // sqlAdministratorLoginPassword: sqlAdministratorLoginPassword
    // trustedServiceBypassEnabled: bool
    // virtualNetworkProfile: {
    //   computeSubnetId: 'string'
    // }
    workspaceRepositoryConfiguration: workspaceRepositoryConfiguration
  }
}

// output the name and id's of the synapse workspace resource once it has been created...

output synapseWorkspaceResourceName string = synapseWorkspace.name
output synapseWorkspaceResourceId string = synapseWorkspace.id
output synapseWorkspaceResourceManagedIdentity string = synapseWorkspace.identity.principalId

// Managed Integration Runtime

resource synapseManagedIR 'Microsoft.Synapse/workspaces/integrationRuntimes@2021-06-01' = {
  name: 'AutoResolveIntegrationRuntime'
  parent: synapseWorkspace
  properties: {
    description: 'Managed vNet IR'
    type: 'Managed'
    typeProperties: {
      computeProperties: {
        location: 'AutoResolve'
        dataFlowProperties: {
          computeType: 'General'
          coreCount: 8
          timeToLive: 0
        }
      }
    }
    // For remaining properties, see IntegrationRuntime objects
  }
}

// SQL Pool

param dedicatedSqlPools object = {}
//   sqlPool1: {
//     name: 'synapseSQL'
//     sku: 'DW1000c' // Use caution with DW1000c, it is a very large and expensive SKU!
//   }
//   sqlPool2: {
//     name: 'synapseSQL2'
//     sku: 'DW100c'
//   }
// }

@allowed([
  'LRS'
  'GRS'
])
param storageAcctType string = 'GRS'

resource synapseSqlPool 'Microsoft.Synapse/workspaces/sqlPools@2021-06-01' = [for pool in items(dedicatedSqlPools): if (!empty(dedicatedSqlPools))  {
  name: pool.value.name
  location: location
  sku: {
    // capacity: int
    name: pool.value.sku
    // tier: 'string'
  }
  parent: synapseWorkspace
  properties: {
    collation: 'SQL_Latin1_General_CP1_CI_AS'
    createMode: 'Default'
    // maxSizeBytes: 240
    // provisioningState: 'string'
    // recoverableDatabaseId: 'string'
    // restorePointInTime: 'string'
    // sourceDatabaseDeletionDate: 'string'
    // sourceDatabaseId: 'string'
    storageAccountType: storageAcctType
  }
}]

// SQL Pool Entra Admins
resource synapseSqlAdmins 'Microsoft.Synapse/workspaces/administrators@2021-06-01' = {
  name: 'activeDirectory'
  parent: synapseWorkspace
  properties: {
    administratorType: 'ActiveDirectory'
    sid: 'e356abf1-b3ef-452c-83f7-7ddfd6a1d089' // SQLAdmins Security Group
    tenantId: subscription().tenantId
  }
}


//Private Endpoints...

param subnetId string

@sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
var dnsZoneConfig = {
  synapseSql: {
    groupId: 'Sql'
    privateDnsZone: 'privatelink.sql.azuresynapse.net'
  }
  synapseSqlOnDemand: {
    groupId: 'SqlOnDemand'
    privateDnsZone: 'privatelink.sql.azuresynapse.net'
  }
  synapseSqlDev: {
    groupId: 'Dev'
    privateDnsZone: 'privatelink.dev.azuresynapse.net'
  }
}

// Module call to create Private Endpoints and Private Endpoint DNS for Synapse...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module synapsePvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = [for zone in items(dnsZoneConfig): if (!empty(subnetId)) {
  name: 'synapse-PvtEp-${zone.value.groupId}-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: synapseWorkspace.id
    pvtEpName: '${synapseWorkspace.name}-${zone.value.groupId}-pvtep'
    location: location
    groupdId: zone.value.groupId
    privateDnsZone: zone.value.privateDnsZone
  }
}]

/////////////////////////
// Diagnostic Settings //
/////////////////////////

// Create Diagnostic Settings for the Synapse Workspace - Send logs to central log analytics workspace
@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'
resource synapseDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${synapseWorkspace.name}-diag'
  scope: synapseWorkspace
  properties: {
    // logAnalyticsDestinationType: null
    workspaceId: defaultLogAnalyticsWorkspaceId
    metrics: []
    logs: [
      {
        category: null
        categoryGroup: 'audit'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: null
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
  }
}
