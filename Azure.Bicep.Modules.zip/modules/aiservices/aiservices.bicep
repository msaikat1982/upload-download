param name string

@description('The location of the AI Cognitive Services.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

param tags object = {}

@allowed([
  'S0'
])
param sku string = 'S0'

param kind string = 'AIServices'

@description('The identity type of the App Service.')
param identityType string = 'SystemAssigned'

param apiStatisticsEnabled bool = false

param disableLocalAuth bool = false

@allowed([
  'Disabled'
])
@description('Should Public Network Access be enabled for this AI Services account.')
param publicNetworkAccess string = 'Disabled'

var customSubDomainName = '${name}-aiservices'

resource aiServices 'Microsoft.CognitiveServices/accounts@2021-10-01' = {
  name: name
  location: location
  tags: tags
  identity: {
    type: identityType
  }
  sku: {
    name: sku
  }
  kind: kind
  properties: {
    customSubDomainName: customSubDomainName
    publicNetworkAccess: publicNetworkAccess
    disableLocalAuth: disableLocalAuth
    apiProperties: {
      statisticsEnabled: apiStatisticsEnabled
    }
  }
}

output aiServicesResourceId string = aiServices.id
output name string = aiServices.name

//Private Endpoints...

param subnetId string

// @sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
// var dnsZoneConfig = {
//   openAi: {
//     groupId: 'account'
//     privateDnsZone: 'privatelink.openai.azure.com'
//   }
//   cogservices: {
//     groupId: 'account'
//     privateDnsZone: 'privatelink.cognitiveservices.azure.com'
//   }
// }

// Module call to create Private Endpoints and Private Endpoint DNS for AI Services...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module aiSrvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = if (!empty(subnetId)) {
  name: 'aisrv-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: aiServices.id
    pvtEpName: '${aiServices.name}-pvtep'
    location: location
    groupdId: 'account'
    privateDnsZones: [
      'privatelink.openai.azure.com'
      'privatelink.cognitiveservices.azure.com'
    ]
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

// Create Diagnostic Settings for AI Services - Send logs to central log analytics workspace
@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'
resource aiServicesDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${aiServices.name}-diag'
  scope: aiServices
  properties: {
    // logAnalyticsDestinationType: null
    workspaceId: defaultLogAnalyticsWorkspaceId
    metrics: []
    logs: [
      {
        category: null
        categoryGroup: 'audit'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: null
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
  }
}

