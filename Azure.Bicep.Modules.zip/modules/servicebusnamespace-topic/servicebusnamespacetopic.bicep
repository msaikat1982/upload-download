//https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces/topics?pivots=deployment-language-bicep#sbtopicproperties

param serviceBusNamespace string

resource servicebusnamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespace
}

param topicName string
param autoDeleteOnIdle string = 'P10675198DT2H48M5.477S' // Never
param defaultMessageTimeToLive string = 'P14D' // 14 Days
param duplicateDetectionHistoryTimeWindow string = 'PT10M' // 10 minutes
param enableBatchedOperations bool = true
param enableExpress bool = false
param enablePartitioning bool = false
param maxMessageSizeInKilobytes int = 1024
param maxSizeInMegabytes int = 1024
param requiresDuplicateDetection bool = false
param status string = 'Active'
param supportOrdering bool = false

resource topic 'Microsoft.ServiceBus/namespaces/topics@2022-10-01-preview' = {
  name: topicName
  parent: servicebusnamespace
  properties: {
    autoDeleteOnIdle: autoDeleteOnIdle
    defaultMessageTimeToLive: defaultMessageTimeToLive
    duplicateDetectionHistoryTimeWindow: duplicateDetectionHistoryTimeWindow
    enableBatchedOperations: enableBatchedOperations
    enableExpress: enableExpress
    enablePartitioning: enablePartitioning
    maxMessageSizeInKilobytes: maxMessageSizeInKilobytes
    maxSizeInMegabytes: maxSizeInMegabytes
    requiresDuplicateDetection: requiresDuplicateDetection
    status: status
    supportOrdering: supportOrdering
  }
}

output topicName string = topic.name
output topicId string = topic.id
