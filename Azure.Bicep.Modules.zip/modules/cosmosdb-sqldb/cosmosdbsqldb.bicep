@description('Name of the Cosmos SQL DB')
param name string

@description('Azure Region to deploy Cosmos SQL DB to')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Tags for the Cosmos SQL DB')
param tags object = {}

@description('Name of the Cosmos DB Account')
param cosmosAccountName string

@description('Max throughput to use with autoscale')
param maxThroughput int = 0

@description('Throughput for this SQL DB')
param throughput int = 400

var autoscaleSettings = maxThroughput > 0 ? {
  maxThroughput: maxThroughput
} : null

var throughputSettings = maxThroughput > 0 ? null : throughput

var options = {
  // include autoscale only if present
  ...(autoscaleSettings != null ? {
    autoscaleSettings: autoscaleSettings
  } : {})

  // include throughput only if present
  ...(throughputSettings != null ? {
    throughput: throughputSettings
  } : {})
}

// Define the SQL Server resource that will act as the parent for the SQL Database
resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-05-15' existing = {
  name: cosmosAccountName
}

resource cosmossql 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2024-05-15' = {
  name: name
  location: location
  tags: tags
  parent: cosmos
  properties: {
    options: options
    resource: {
      id: name
    }
  }
}

output cosmossqlResourceId string = cosmossql.id
output cosmossqlResourceName string = cosmossql.name
