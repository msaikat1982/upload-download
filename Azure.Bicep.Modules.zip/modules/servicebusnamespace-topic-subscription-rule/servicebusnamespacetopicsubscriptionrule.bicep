// https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces/topics/subscriptions/rules?pivots=deployment-language-bicep#correlationfilterproperties

param serviceBusNamespace string
param subscriptionName string
param topicName string
param filterType string = 'SqlFilter'
param sql_sqlExpression string
param ruleName string

// action:
// param action_compatibilityLevel int = 20
// param action_requiresPreprocessing bool = false
// param action_sqlExpression string 
    
// // correlationFilter: 
// param contentType string
// param correlationId string
// param label string
// param messageId string
// param replyTo string
// param replyToSessionId string
// param correlation_requiresPreprocessing bool
// param sessionId string
// param to string 

// sql filter
// param sql_compatibilityLevel int = 20
// param sql_requiresPreprocessing bool

resource sbnamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespace

  resource topic 'topics' existing = {
    name: topicName

    resource sub 'subscriptions' existing = {
      name: subscriptionName

      resource rule 'rules' = {
        name: ruleName
        properties: {
          // action: {
          //   compatibilityLevel: action_compatibilityLevel
          //   requiresPreprocessing: action_requiresPreprocessing
          //   sqlExpression: action_sqlExpression
          // }
          // correlationFilter: {
          //   contentType: contentType
          //   correlationId: correlationId
          //   label: label
          //   messageId: messageId
          //   // properties: {
          //   //   {customized property}: 'string'
          //   // }
          //   replyTo: replyTo
          //   replyToSessionId: replyToSessionId
          //   requiresPreprocessing: correlation_requiresPreprocessing
          //   sessionId: sessionId
          //   to: to
          // }
          filterType: filterType
          sqlFilter: {
            // compatibilityLevel: sql_compatibilityLevel
            // requiresPreprocessing: sql_requiresPreprocessing
            sqlExpression: sql_sqlExpression
          }
        }  
      }
    }
  }
}

output ruleName string = sbnamespace::topic::sub::rule.name
output ruleId string = sbnamespace::topic::sub::rule.id
