@description('Details of the API.')
type apiCenterObject = {
  @description('The name of the API center.')
  apiCenterName: string
  @description('The name of an API to register in the API center.')
  apiName: string
  @description('The version of an API to register in the API center.')
  apiVersion: string
  @description('The type of the API to register in the API center.')
  apiType: apiTypeObject
  @description('Summary of the API.')
  apiSummary: string
  @description('Description of the API.')
  apiDescription: string
  @description('External documentation title.')
  externalDocs: externalDocObject[]
  @description('Contact Name for the API.')
  contactName: string
  @description('Contact Email for the API.')
  contactEmail: string
  @description('Contact URL for the API.')
  contactUrl: string
  @description('Custom property: public facing.')
  customPublicFacing: bool
  @description('Custom property: line of business tags.')
  customLineOfBusiness: apiLobObject
  @description('Custom property: tier 1 support.')
  customTier1Support: bool
  @description('Lifecycle stage for the API version.')
  lifecycleStage: string
  @description('API definition title.')
  apiDefinitionTitle: string
  @description('Deployments.')
  deployments: deploymentsObject[]
}

@description('Details of the API type.')
type apiTypeObject = 'rest' | 'soap' | 'graphql' | 'grpc' | 'webhook' | 'websocket'

@description('Details of the LoB.')
type apiLobObject = ('IT' | 'Marketing' | 'Member' | 'Provider' | 'Claims' | 'Dental')[]

@description('External documentation object.')
type externalDocObject = {
  externalDocTitle: string
  externalDocDescription: string
  externalDocUrl: string
}

@description('External documentation object.')
type deploymentsObject = {
  deploymentDescription: string
  deploymentEnvironmentId: string
  deploymentRuntimeUris: string[]
  deploymentState: string
}

@description('The details of the API.')
param apiDetails apiCenterObject

resource apiCenterWorkspace 'Microsoft.ApiCenter/services/workspaces@2024-03-01' existing = {
  name: '${apiDetails.apiCenterName}/default'
}

resource apiCenterAPI 'Microsoft.ApiCenter/services/workspaces/apis@2024-03-01' = {
  parent: apiCenterWorkspace
  name: toLower(apiDetails.apiName)
  properties: {
    title: apiDetails.apiName
    kind: apiDetails.apiType
    externalDocumentation: [for doc in apiDetails.externalDocs: {
      description: doc.externalDocDescription
      title: doc.externalDocTitle
      url: doc.externalDocUrl
      }
    ]
    contacts: [
      {
        name: apiDetails.contactName
        email: apiDetails.contactEmail        
        url: apiDetails.contactUrl
      }
    ]
    customProperties: {
      publicfacing: apiDetails.customPublicFacing
      lineofbusiness: apiDetails.customLineOfBusiness
      tier1support: apiDetails.customTier1Support
    }
    summary: apiDetails.apiSummary
    description: apiDetails.apiDescription
  }
}

output apiCenterApi_Name string = apiCenterAPI.name
output apiCenterApi_Id string = apiCenterAPI.id

resource apiCenterAPIVersion 'Microsoft.ApiCenter/services/workspaces/apis/versions@2024-06-01-preview' = {
  parent: apiCenterAPI
  name: '${apiDetails.apiName}-${apiDetails.apiVersion}'
  properties: {
    title: apiDetails.apiVersion
    lifecycleStage: apiDetails.lifecycleStage
  }
}

resource apiCenterAPIDefinition 'Microsoft.ApiCenter/services/workspaces/apis/versions/definitions@2024-06-01-preview' = {
  parent: apiCenterAPIVersion
  name: '${apiDetails.apiName}-def'
  properties: {
    title: apiDetails.apiDefinitionTitle
  }
}

output apiCenterAPIDefinition_Name string = apiCenterAPIDefinition.name
output apiCenterAPIDefinition_Id string = apiCenterAPIDefinition.id

resource apiCenterDeployment 'Microsoft.ApiCenter/services/workspaces/apis/deployments@2024-06-01-preview' = [for (deployment, i) in apiDetails.deployments: {
  parent: apiCenterAPI
  name: take('${apiDetails.apiName}-${last(split(deployment.deploymentEnvironmentId, '/'))}-deployment', 50)
  properties: {
    definitionId: '/workspaces/default/apis/${apiCenterAPI.name}/versions/${apiCenterAPI.name}-${apiDetails.apiVersion}/definitions/${apiCenterAPIDefinition.name}'
    description: deployment.deploymentDescription
    environmentId: deployment.deploymentEnvironmentId
    server: {
      runtimeUri: deployment.deploymentRuntimeUris
    }
    state: deployment.deploymentState
    title: take('${apiDetails.apiName}-${last(split(deployment.deploymentEnvironmentId, '/'))}', 50)
  }
}]

output apiCenterDeployments array = [
  for (deployment, i) in apiDetails.deployments: {
    name: apiCenterDeployment[i].name
    id: apiCenterDeployment[i].id
  }
]
