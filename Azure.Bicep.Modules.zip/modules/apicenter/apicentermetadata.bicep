param apiCenterName string
param metadataDetails array

resource apiCenter 'Microsoft.ApiCenter/services@2024-06-01-preview' existing = {
  name: apiCenterName
}

resource metadata 'Microsoft.ApiCenter/services/metadataSchemas@2024-06-01-preview' = [for detail in metadataDetails: {
  parent: apiCenter
  name: detail.name
  properties: detail.properties
}]
