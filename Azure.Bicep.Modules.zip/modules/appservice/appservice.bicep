////////////////////////
// Default Parameters //
////////////////////////

@description('The name of the App Service Plan')
param name string

@description('The Azure region to deploy the App Service Plan.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Azure resource tags provided as key/value object.')
param tags object = {}

param kind string

/////////////////////////////
// App Service Parameters //
////////////////////////////

@description('The identity type of the App Service.')
param identityType string = 'SystemAssigned'

@description('Whether only HTTPS is allowed for the App Service.')
param httpsOnly bool = true

@description('Whether the App Service should be kept running all the time, even when there is no incoming request.')
param alwaysOn bool = false

@description('A collection of key-value pairs representing the application settings for the App Service.')
param appSettings array = []

@description('Connection strings to be used by the App Service to connect to external resources.')
param ftpsState string = 'FtpsOnly'

@description('Whether or not to send client session affinity cookies.')
param clientAffinityEnabled bool = true

@description('Which Java version to use for the App Service.')
param javaVersion string = ''

@description('Which .NET Framework version to use for the App Service.')
param netFrameworkVersion string = ''

@description('Which Node.js version to use for the App Service.')
param nodeVersion string = ''

@description('Which PHP version to use for the App Service.')
param phpVersion string = ''

@description('Which PowerShell version to use for the App Service.')
param powerShellVersion string = ''

@description('Which Python version to use for the App Service.')
param pythonVersion string = ''

@description('The Runtime stack of current web app')
param linuxFxVersion string = ''  // format stack|version

@allowed([
  'Disabled'
])
@description('Property to allow or block all public traffic for the App Service.')
param publicNetworkAccess string = 'Disabled'

@description('Property to use or not use 32-bit worker process.')
param use32BitWorkerProcess bool = false

@description('Property to use or not enable error logging for the App Service.')
param detailedErrorLoggingEnabled bool = true

@description('Name of the associated App Service plan.')
param aspName string

@description('Name of the App Insights instance to connect to.')
param appInsightsName string

@description('Azure Resource Manager ID of the Virtual network and subnet to be joined by Regional VNET Integration.')
param vNetSubnetId string

//Pulling in asp resource to get id for app service

resource asp 'Microsoft.Web/serverfarms@2022-09-01' existing = {
  name: aspName
}

resource appInsights 'Microsoft.Insights/components@2020-02-02' existing = if(!empty(appInsightsName)) {
  name: appInsightsName
}

////////////////////////////////
// App Service Resource Call //
///////////////////////////////

resource appService 'Microsoft.Web/sites@2022-09-01' = {
  name: name
  location: location
  tags: tags
  kind: kind
  identity: {
    type: identityType
  }
  properties: {
    virtualNetworkSubnetId: vNetSubnetId
    clientAffinityEnabled: clientAffinityEnabled
    httpsOnly: httpsOnly
    serverFarmId: asp.id
    publicNetworkAccess: publicNetworkAccess
    siteConfig: {
      alwaysOn: alwaysOn
      appSettings: (!(empty(appInsightsName)) ? union(appSettings, [
        {
          name: 'APPINSIGHTS_INSTRUMENTATIONKEY'
          value: appInsights.properties.InstrumentationKey
        }
        {
          name: 'APPLICATIONINSIGHTS_CONNECTION_STRING'
          value: appInsights.properties.ConnectionString
        }
      ]) : appSettings)
      ftpsState: ftpsState   
      javaVersion: !empty(javaVersion) ? javaVersion : null
      minTlsVersion: '1.2'
      netFrameworkVersion: !empty(netFrameworkVersion) ? netFrameworkVersion : null
      nodeVersion: !empty(nodeVersion) ? nodeVersion : null
      phpVersion: !empty(phpVersion) ? phpVersion : null
      powerShellVersion: !empty(powerShellVersion) ? powerShellVersion : null
      pythonVersion: !empty(pythonVersion) ? pythonVersion : null
      linuxFxVersion: kind == 'linux' ? linuxFxVersion : null
      use32BitWorkerProcess: use32BitWorkerProcess
      publicNetworkAccess: publicNetworkAccess
      detailedErrorLoggingEnabled: detailedErrorLoggingEnabled
    }
  }
}

output appServiceResourceId string = appService.id
output appServiceResourceName string = appService.name

//Private Endpoints...

param subnetId string

// @sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
// var dnsZoneConfig = {
//   app: {
//     groupId: 'sites'
//     privateDnsZone: 'privatelink.azurewebsites.net'
//   }
//   appscm: {
//     groupId: 'sites'
//     privateDnsZone: 'scm.privatelink.azurewebsites.net'
//   }
// }

// Module call to create Private Endpoints and Private Endpoint DNS for App service...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module appSrvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = if (!empty(subnetId)) {
  name: 'appService-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: appService.id
    pvtEpName: '${appService.name}-pvtep'
    location: location
    groupdId: 'sites'
    privateDnsZones: [
      'privatelink.azurewebsites.net'
      'scm.privatelink.azurewebsites.net'
    ]
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'

var eventHubNamespaceMap = {
  centralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-c-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  eastus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-e-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  northcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Ops0-DCRG/providers/Microsoft.EventHub/namespaces/net0-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
  southcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/OPS1-DCRG/providers/Microsoft.EventHub/namespaces/net1-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
}

@description('Based on location of Service Bus, use eventHub in that region.')
var eventHubRuleId = eventHubNamespaceMap[location]

@description('Map eventHubName namespace to the eventHub name within the namespace')
var eventHubNameMap = {
  centralus: 'insights-operational-logs'
  eastus: 'insights-operational-logs'
  northcentralus: 'insights-operational-logs'
  southcentralus: 'insights-operational-logs'
}

@description('Get the Event Hub name from the appropriate namespace')
var eventHubName = eventHubNameMap[location]

resource serviceBusDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${appService.name}-diag'
  scope: appService
  properties: {
    workspaceId: defaultLogAnalyticsWorkspaceId
    eventHubAuthorizationRuleId: eventHubRuleId
    eventHubName: eventHubName
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
  }
}
