// Required Params

@description('The location of the Azure SQL Server.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('The name of the Azure SQL Server.')
param name string

@description('The SQL administrator login name.')
param adminLogin string

@description('The SQL administrator password.')
@secure()
param adminPassword string

// Optional Params

@description('The Azure Active Directory Tenant ID for the SQL Server.')
param adauth_tenantId string = tenant().tenantId

@description('SQL Server Minimal TLS Version.')
@allowed([
  '1.2'
])
param minimalTlsVersion string = '1.2'

@description('Whether or not to enable Public Access to this SQL Server.')
@allowed([
  'Disabled'
  'Enabled'
  'SecuredByPerimeter'
])
param publicNetworkAccess string = 'Disabled'

@description('Tags to apply to the Azure SQL Server.')
param tags object

resource sqlServer 'Microsoft.Sql/servers@2024-05-01-preview' = {
  name: name
  location: location
  tags: tags
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    administratorLogin: adminLogin  // required on creation
    administratorLoginPassword: adminPassword // required on creation
    version: '12.0'
    minimalTlsVersion: minimalTlsVersion
    publicNetworkAccess: publicNetworkAccess
    administrators: {
      administratorType: 'ActiveDirectory'
      principalType: 'Group'
      login: 'SQLAdmins'
      sid: 'e356abf1-b3ef-452c-83f7-7ddfd6a1d089'
      tenantId: adauth_tenantId
    }
    restrictOutboundNetworkAccess: 'Disabled'
  }
}

// Individual resource call to set AD Only Auth setting since it is not supported in the main SQL Server resource
resource symbolicname 'Microsoft.Sql/servers/azureADOnlyAuthentications@2024-11-01-preview' = {
  parent: sqlServer
  name: 'Default'
  properties: {
    azureADOnlyAuthentication: false
  }
}

// Module call to create Private Endpoints and Private Endpoint DNS for SQL Server

@description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
var dnsZoneConfig = {
  sqlServer: {
    groupId: 'sqlServer'
    privateDnsZone: 'privatelink.database.windows.net'
  }
}

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

@description('Specifies the full subnet Resource Id for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = ''

module sqlServerPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = [for zone in items(dnsZoneConfig): if (!empty(subnetId)) {
  name: 'sqlServer-PvtEp-${zone.value.groupId}-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: sqlServer.id
    pvtEpName: '${sqlServer.name}-${zone.value.groupId}-pvtep'
    location: location
    groupdId: zone.value.groupId
    privateDnsZone: zone.value.privateDnsZone
  }
}]

output sqlServerResourceId string = sqlServer.id
output sqlServerName string = sqlServer.name
