@description('The name of the Cosmos DB Account')
param name string

@description('Azure Region to deploy Cosmos DB Account to')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

param tags object

@allowed([
  'GlobalDocumentDB'
  'MongoDB'
  'Parse'
])
@description('Cosmos DB Kinds.')
param kind string = 'GlobalDocumentDB'

@description('Identity Type used by Cosmos DB.')
param identityType string = 'SystemAssigned'

@allowed([
  'Disabled'
  'SecuredByPerimeter'
])
@description('Should Public Network Access be enabled for this CosmosDB account.')
param publicNetworkAccess string = 'Disabled'

@description('Enables automatic failover of the write region in the rare event that the region is unavailable due to an outage.')
param enableAutomaticFailover bool = false

@description('Flag to indicate whether to enable/disable Virtual Network ACL rules.')
param isVirtualNetworkFilterEnabled bool = false

@description('List of Virtual Network ACL rules configured for the Cosmos DB account.')
param virtualNetworkRules array = []

@description('Disable write operations on metadata resources (databases, containers, throughput) via account keys')
param disableKeyBasedMetadataWriteAccess bool = false

@description('Flag to indicate whether Free Tier is enabled.')
param enableFreeTier bool = false

@description('Flag to indicate whether to enable storage analytics.')
param enableAnalyticalStorage bool = true

@allowed([
  'Default'
  'Restore'
])
@description('Enum to indicate the mode of account creation.')
param createMode string = 'Default'

@description('The offer type for the database')
param databaseAccountOfferType string = 'Standard'

@allowed([
  'Eventual'
  'ConsistentPrefix'
  'Session'
  'BoundedStaleness'
  'Strong'
])
@description('The default consistency level of the Cosmos DB account.')
param defaultConsistencyLevel string = 'Session'

@minValue(10)
@maxValue(2147483647)
@description('Max stale requests. Required for BoundedStaleness. Valid ranges, Single Region: 10 to 2147483647. Multi Region: 100000 to 2147483647.')
param maxStalenessPrefix int = 100000

@minValue(5)
@maxValue(86400)
@description('Max lag time (minutes). Required for BoundedStaleness. Valid ranges, Single Region: 5 to 84600. Multi Region: 300 to 86400.')
param maxIntervalInSeconds int = 300

@description('The consistency policy for the Cosmos DB account.')
var consistencyPolicy = {
  Eventual: {
    defaultConsistencyLevel: 'Eventual'
  }
  ConsistentPrefix: {
    defaultConsistencyLevel: 'ConsistentPrefix'
  }
  Session: {
    defaultConsistencyLevel: 'Session'
  }
  BoundedStaleness: {
    defaultConsistencyLevel: 'BoundedStaleness'
    maxStalenessPrefix: maxStalenessPrefix
    maxIntervalInSeconds: maxIntervalInSeconds
  }
  Strong: {
    defaultConsistencyLevel: 'Strong'
  }
}

@description('Primary location to for Cosmos DB Account to write to')
var defaultLocation = [
  {
    locationName: location
    failoverPriority: 0
    isZoneRedundant: false
  }
]

@description('Enables the account to write in multiple locations')
param enableMultipleWriteLocations bool = false

@description('Additional locations for account to write to') //Requires enableMultipleWriteLocations = true
param extraLocations array = []

@description('Combined Array for all locations for Cosmos DB Account to Write To')
var locations = union(defaultLocation, extraLocations)

@description('The CORS policy for the Cosmos DB database account.')
param cors array = []

@description('List of Cosmos DB capabilities for the account')
param capabilities array = []

@description('List of IpRules.')
param ipRules array = []

@description('The object representing the policy for taking backups on an account.')
param backupPolicy object = {
  continuousModeProperties: {
    tier: 'Continuous7Days'
  }
  type: 'Continuous'
}

@description('Default Required Tags for Cosmos DB Account')
var defaultTags = {
  defaultExperience: 'Core (SQL)'
  'hidden-cosmos-mmspecial': ''
  CosmosAccountType: 'Non-Production'
}

@description('')
var resourceTags = union(tags, defaultTags)

resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2024-12-01-preview' = {
  name: name
  location: location
  tags: resourceTags
  kind: kind
  identity: {
    type: identityType
  }
  properties: {
    publicNetworkAccess: publicNetworkAccess
    enableAutomaticFailover: enableAutomaticFailover
    enableMultipleWriteLocations: enableMultipleWriteLocations
    isVirtualNetworkFilterEnabled: isVirtualNetworkFilterEnabled
    virtualNetworkRules: virtualNetworkRules
    disableKeyBasedMetadataWriteAccess: disableKeyBasedMetadataWriteAccess
    enableFreeTier: enableFreeTier
    enableAnalyticalStorage: enableAnalyticalStorage
    createMode: createMode
    databaseAccountOfferType: databaseAccountOfferType
    consistencyPolicy: consistencyPolicy[defaultConsistencyLevel]
    locations: locations
    cors: cors
    capabilities: capabilities
    ipRules: ipRules
    backupPolicy: backupPolicy
  }
}

//Private Endpoints...

param subnetId string

// Module call to create Private Endpoints and Private Endpoint DNS for CosmosDB...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module cosmosPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = if (!empty(subnetId)) {
  name: 'cosmos-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: cosmos.id
    pvtEpName: '${cosmos.name}-pvtep'
    location: location
    groupdId: 'Sql'
    privateDnsZone: 'privatelink.documents.azure.com'
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'

var eventHubNamespaceMap = {
  centralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-c-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  eastus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-e-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  northcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Ops0-DCRG/providers/Microsoft.EventHub/namespaces/net0-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
  southcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/OPS1-DCRG/providers/Microsoft.EventHub/namespaces/net1-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
}

@description('Based on location of Service Bus, use eventHub in that region.')
var eventHubRuleId = eventHubNamespaceMap[location]

@description('Map eventHubName namespace to the eventHub name within the namespace')
var eventHubNameMap = {
  centralus: 'insights-operational-logs'
  eastus: 'insights-operational-logs'
  northcentralus: 'insights-operational-logs'
  southcentralus: 'insights-operational-logs'
}

@description('Get the Event Hub name from the appropriate namespace')
var eventHubName = eventHubNameMap[location]

resource cosmosDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${cosmos.name}-diag'
  scope: cosmos
  properties: {
    workspaceId: defaultLogAnalyticsWorkspaceId
    eventHubAuthorizationRuleId: eventHubRuleId
    eventHubName: eventHubName
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
  }
}


output cosmosResourceId string = cosmos.id
output cosmosResourceName string = cosmos.name
output cosmosDocEndpoint string = cosmos.properties.documentEndpoint

