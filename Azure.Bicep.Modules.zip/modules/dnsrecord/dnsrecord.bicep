/* 
https://learn.microsoft.com/en-us/azure/templates/microsoft.network/dnszones/a?pivots=deployment-language-bicep

This module is used to create DNS A records in an existing Private DNS Zone for Azure VM's.

It is called from the virtualmachine.bicep module.

*/ 

@description('Expects the name of the VM')
param name string

@description('Expects the private IP of a VM Nic')
param privateIp string

@description('Expects the name of the DNS zone to register A record in.')
param dnsZoneName string

@description('Time-to-Live for DNS reservations.')
param ttl int = 300

resource existingDnsZone 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: dnsZoneName
}

resource aRecord 'Microsoft.Network/privateDnsZones/A@2024-06-01' = {
  name: name
  parent: existingDnsZone
  properties: {
    ttl: ttl
    aRecords: [
      { ipv4Address: privateIp }
    ]
  }
}
