////////////////////////
// Default Parameters //
////////////////////////

@description('The name of the App Service Plan')
param name string

@description('The Azure region to deploy the App Service Plan.')
@allowed(['centralus','eastus','southcentralus'])
param location string

@description('Azure resource tags provided as key/value object.')
param tags object = {}

// App Service Plan

/////////////////////////////////
// App Service Plan Parameters //
/////////////////////////////////

@description('The type of service and its capabilities.')
param kind string

// @description('App Service Plan SKU Name that does NOT allow for zone redundancy.')
var zoneRedundantUnsupportedSkus = [
  'F1'
  'B1'
  'B2'
  'B3'
  'S1'
  'S2'
  'S3'
]

// @description('App Service Plan SKU Name that allows for zone redundancy.')
// var zoneRedundantSupportedSkus = [
//   'P0v3'
//   'P1v3'
//   'P2v3'
//   'P3v3'
//   'P1mv3'
//   'P2mv3'
//   'P3mv3'
//   'P4mv3'
//   'P5mv3'
//   'P1v2'
//   'P2v2'
//   'P3v2'
// ]

@minLength(2)
@description('The SKU name of the App Service Plan.')
param skuName string

@minValue(1)
@maxValue(100)
@description('The number of instances to allocate for the App Service Plan.')
param capacity int = 2

@description('Enable zone redundancy for the App Service Plan. If true, the plan will be deployed across multiple availability zones.')
param zoneRedundant bool = true

resource asp 'Microsoft.Web/serverfarms@2022-09-01' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: skuName
    capacity: capacity
  }
  kind: kind
  properties: {
    reserved: kind == 'linux'
    // spread operator to add zoneRedundant property only if skuName is not in the zoneRedundantUnsupportedSkus array
    ...(!contains(zoneRedundantUnsupportedSkus, skuName) ? {
      zoneRedundant: zoneRedundant
    } : {})
  }
}
//Removing Diagnostic Settings since Metric logs are added by policy

// /////////////////////////
// // Diagnostic Settings //
// /////////////////////////

// // Create Diagnostic Settings for App Service Plan - Send logs to central log analytics workspace
// @description('The log analytics workspace ID for diagnostic settings')
// param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'
// resource appDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
//   name: '${asp.name}-diag'
//   scope: asp
//   properties: {
//     // logAnalyticsDestinationType: null
//     workspaceId: defaultLogAnalyticsWorkspaceId
//     logs: []
//     metrics: [
//       {
//           enabled: true
//           retentionPolicy: {
//               days: 0
//               enabled: false
//           }
//           category: 'AllMetrics'
//       }
//     ]    
//   }
// }

output aspResourceName string = asp.name
output aspResourceId string = asp.id
