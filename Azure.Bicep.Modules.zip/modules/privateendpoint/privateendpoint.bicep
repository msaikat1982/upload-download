@description('The Id of the subnet that will host the Private Endpoint.')
param subnetId string

@description('The Id of the Azure resource that we are giving a Private Endpoint.')
param resourceId string

@description('The name of the Private Endpoint.')
param pvtEpName string

@description('The Azure Region of the Private Endpoint.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('The Private DNS Zone where the Private Endpoint will be registered.')
param privateDnsZone string = ''

@description('The Private DNS Zones where the Private Endpoint will be registered.')
param privateDnsZones array = []

@description('The Group Id of the Private DNS Zone.')
param groupdId string

var dnsZones = !empty(privateDnsZones) ? privateDnsZones : [
  privateDnsZone
]

// Get the existing Private DNS Zone...
resource pvtDnsZone 'Microsoft.Network/privateDnsZones@2020-06-01' existing = [for zone in dnsZones: {
  scope: resourceGroup('f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e','rg-tio-dns-southcentralus-01')
  name: zone
}]

// Create the Private Endpoint...
resource pvtEp 'Microsoft.Network/privateEndpoints@2023-09-01' = {
  name: pvtEpName
  location: location
  properties: {
    privateLinkServiceConnections: [
      {
        name: pvtEpName
        properties: {
          groupIds: [groupdId]
          privateLinkServiceId: resourceId
        }
      }
    ]
    subnet: {
      id: subnetId
    }
  }
}

// Configure the Private DNS Zone on the Private Endpoint...
resource pvtEpDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-09-01' = {
  name: groupdId
  parent: pvtEp
  dependsOn: [pvtDnsZone]
  properties: {
    privateDnsZoneConfigs: [for (zone, i) in dnsZones: {
        name: zone
        properties: {
          privateDnsZoneId: pvtDnsZone[i].id
        }
      }
    ]
  }
}

output privateEndPointName string = pvtEp.name
output privateEndPointId string = pvtEp.id
