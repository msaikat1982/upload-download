@description('The tenant ID where the Key Vault is deployed')
param tenantId string = subscription().tenantId

@description('Key Vault Name')
@minLength(3)
@maxLength(24)
param keyVaultName string

@description('Azure Region to deploy Key Vault')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Environment for Key Vault')
@allowed(['poc','dev','tst','stg','prd'])
param env string

@description('The full Resource ID of the subnet for keyvault Private Endpoint')
param subnetId string

@description('Azure resource tags provided as key/value object')
param tags object = {}

@description('Specifies whether soft delete should be enabled for the Key Vault.')
param enableSoftDelete bool = true

@description('The number of days to retain deleted data in the Key Vault.')
param softDeleteRetentionInDays int = 90

@description('The SKU name of the Key Vault.')
@allowed(['standard', 'premium'])
param skuName string = 'standard'

@allowed(['A', 'B'])
@description('The SKU family of the Key Vault.')
param skuFamily string = 'A'

param enabledForDeployment bool = false
param enabledForDiskEncryption bool = false
param enabledForTemplateDeployment bool = false
param publicNetworkAccess string = 'disabled'

@description('Boolean param to decide if AKS Key Vault provider needs access to the Key Vault.')
param isAKSintegrated bool = false

// deploy the key vault...

resource kv 'Microsoft.KeyVault/vaults@2021-11-01-preview' = {
  name: keyVaultName
  location: location
  tags: tags
  properties: {
    tenantId: tenantId
    sku: {
      name: skuName
      family: skuFamily
    }
    networkAcls: {
      defaultAction: 'Allow'
      bypass: 'AzureServices'
    }
    enabledForDeployment: enabledForDeployment
    enabledForDiskEncryption: enabledForDiskEncryption
    enabledForTemplateDeployment: enabledForTemplateDeployment    
    enableSoftDelete: enableSoftDelete
    softDeleteRetentionInDays: softDeleteRetentionInDays
    publicNetworkAccess: publicNetworkAccess
    enableRbacAuthorization: true
  }
}

// output the name  and id of the keyvault resource once it has been created...

output keyvaultResourceName string = kv.name
output keyvaultResourceId string = kv.id

///////////////////
// Keyvault RBAC //
///////////////////

// https://learn.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli#azure-built-in-roles-for-key-vault-data-plane-operations

// if isAKSintegrated == true, the AKS key vault provider MSI is given access to the keyvault...

@description('Map [env] to an AKS user assigned Managed Identity. These IDs are specific to the Azure Key Vault provider for AKS.')
var aksIdMap = {
  dev: '6e257972-cdd9-48d7-a602-f405f4e461c2'
  tst: 'e50aa7e3-82e8-434d-9d3d-04ecee6fd926'
  stg: '22cc367b-28ec-4820-88c5-1d23e4afef2c'
  prd: '79e45d66-cdc7-4b4d-98b9-ce39a44fb5e6'
}
var aksUserId = aksIdMap[env]

var keyvaultAksRbac = [
  {
    roleName: 'Key Vault Certificate User'
    roleId: 'db79e9a7-68ee-4b58-9aeb-b90e7c24fcba'
    principals: [
      aksUserId
    ]
  }
  {
    roleName: 'Key Vault Crypto User'
    roleId: '12338af0-0e69-4776-bea7-57ae8d297424'
    principals: [
      aksUserId
    ]
  }
  {
    roleName: 'Key Vault Secrets User'
    roleId: '4633458b-17de-408a-b874-0445c86b69e6'
    principals: [
      aksUserId
    ]
  }
]

// this is the default RBAC that every key vault is deployed with...

var defaultKeyvaultRbac = [
  {
    roleName: 'Key Vault Certificates Officer'
    roleId: 'a4417e6f-fecd-4de8-b567-7b0420556985'
    principals: [
      '91f4d3e7-5e8b-4114-a314-38bd3b0c4e33' // Venafi
      '44a965df-022c-419d-b52b-9b08d8580770' // Security Analysts - Admin_Cloud
      '9e415126-0d03-46da-8d90-860c692e45b1' // Azure_AzureDevOps-Admin
    ]
  }
  {
    roleName: 'Key Vault Crypto Officer'
    roleId: '14b46e9e-c2b7-41b4-b07b-48a6ebf60603'
    principals: [
      '44a965df-022c-419d-b52b-9b08d8580770' // Security Analysts - Admin_Cloud
      '9e415126-0d03-46da-8d90-860c692e45b1' // Azure_AzureDevOps-Admin
    ]
  }
  {
    roleName: 'Key Vault Secrets Officer'
    roleId: 'b86a8fe4-44ce-4948-aee5-eccb2c155cd7'
    principals: [
      '44a965df-022c-419d-b52b-9b08d8580770' // Security Analysts - Admin_Cloud
      '9e415126-0d03-46da-8d90-860c692e45b1' // Azure_AzureDevOps-Admin
    ]
  }
  {
    roleName: 'Key Vault Secrets User'
    roleId: '4633458b-17de-408a-b874-0445c86b69e6'
    principals: [
      '91f4d3e7-5e8b-4114-a314-38bd3b0c4e33' // Venafi
      '62892d57-b3b9-46d1-80aa-1e059931513f' // Technology Infrastructure Platform - Admin
    ]
  }
  {
    roleName: 'Key Vault Certificate User'
    roleId: 'db79e9a7-68ee-4b58-9aeb-b90e7c24fcba'
    principals: [
      '62892d57-b3b9-46d1-80aa-1e059931513f' // Technology Infrastructure Platform - Admin
    ]
  }
  {
    roleName: 'Key Vault Crypto User'
    roleId: '12338af0-0e69-4776-bea7-57ae8d297424'
    principals: [
      '91f4d3e7-5e8b-4114-a314-38bd3b0c4e33' // Venafi
    ]
  }
  {
    roleName: 'Key Vault Purge Operator'
    roleId: 'a68e7c17-0ab2-4c09-9a58-125dae29748c'
    principals: [
      '62892d57-b3b9-46d1-80aa-1e059931513f' // Technology Infrastructure Platform - Admin
    ]
  }
]

// if isAKSintegrated == true, combine keyvaultAksRbac, defaultkeyvaultRbac, and rbac. otherwise just use defaultKeyvaultRBAC and rbac...

param rbac array = []

var combinedArray = isAKSintegrated ? union(keyvaultAksRbac, defaultKeyvaultRbac, rbac) : union(defaultKeyvaultRbac, rbac)

// map rbac array to return an object for each principal...
var rbacObj = [for item in combinedArray: map(item.principals, principal => {
  roleName: item.roleName
  roleId: item.roleId
  principal: principal
})]

// flatten function returns an array of subarray objects...
var flattenedObj = flatten(rbacObj)

// iterate to create a role assignment for each principal item...
resource kvRoleAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for item in flattenedObj: {
  name: guid(kv.name, item.roleId, item.principal)
  scope: kv
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', item.roleId)
    principalId: item.principal // Referencing principal ID using the web app resource
  }
}]

// create Private Endpoints and Private Endpoint DNS for the keyvault...

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module kvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'kv-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: kv.id
    pvtEpName: '${kv.name}-pvtep'
    location: location
    groupdId: 'vault'
    privateDnsZone: 'privatelink.vaultcore.azure.net'
  }
}
