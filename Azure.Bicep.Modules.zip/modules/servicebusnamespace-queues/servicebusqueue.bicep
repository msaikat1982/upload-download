// https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces/queues?pivots=deployment-language-bicep

param serviceBusNamespace string

resource servicebusnamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' existing = {
  name: serviceBusNamespace
}

param queueName string
param maxDeliveryCount int = 10
param maxSizeInMegabytes int = 1024
param autoDeleteOnIdle string = 'P10675198DT2H48M5.477S' // Never
param deadLetteringOnMessageExpiration bool = false
param defaultMessageTimeToLive string = 'P14D' // 14 Days
param duplicateDetectionHistoryTimeWindow string = 'PT10M' // 10 minutes
param enableBatchedOperations bool = true
param enableExpress bool = false
param enablePartitioning bool = false
param lockDuration string = 'PT1M' // 1 minute
param maxMessageSizeInKilobytes int = 1024
param requiresDuplicateDetection bool = false
param requiresSession bool = false

resource queue 'Microsoft.ServiceBus/namespaces/queues@2022-10-01-preview' = {
  name: queueName
  parent: servicebusnamespace
  properties: {
    autoDeleteOnIdle: autoDeleteOnIdle
    deadLetteringOnMessageExpiration: deadLetteringOnMessageExpiration
    defaultMessageTimeToLive: defaultMessageTimeToLive
    duplicateDetectionHistoryTimeWindow: duplicateDetectionHistoryTimeWindow
    enableBatchedOperations: enableBatchedOperations
    enableExpress: enableExpress
    enablePartitioning: enablePartitioning
    lockDuration: lockDuration
    maxDeliveryCount: maxDeliveryCount
    maxMessageSizeInKilobytes: maxMessageSizeInKilobytes
    maxSizeInMegabytes: maxSizeInMegabytes
    requiresDuplicateDetection: requiresDuplicateDetection
    requiresSession: requiresSession

  }
}

output queueName string = queue.name
output queueId string = queue.id
