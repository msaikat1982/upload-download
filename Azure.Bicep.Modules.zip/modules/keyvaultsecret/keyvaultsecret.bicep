@description('The Key vault where the Secret is deployed')
param keyvaultName string

@description('An array of arrays for passing values as bicepParameters')
param secrets array
// Multiple secrets:
// [
//   ['secretname1','val1']
//   ['secretname2','val2']
// ]
// Single secret:
// ['secretname1','val1']

@description('Secret enabled or disabled')
param enabled bool = true

@description('Azure resource tags provided as key/value object')
param tags object = {}

resource kv 'Microsoft.KeyVault/vaults@2023-02-01' existing = {
  name: keyvaultName
}

resource secret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = if (length(secrets[0]) > 2) {
  name: secrets[0]
  parent: kv
  properties: {
    value: '${secrets[1]}'
    attributes: {
      enabled: enabled
    }
  }
  tags: tags
}

resource multisecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = [for i in range(0, length(secrets)): if ((length(secrets[0]) == 2) && (length(secrets) >= 2)) {
  name: '${secrets[i][0]}'
  parent: kv
  properties: {
    value: '${secrets[i][1]}'
    attributes: {
      enabled: enabled
    }
  }
  tags: tags
}]
