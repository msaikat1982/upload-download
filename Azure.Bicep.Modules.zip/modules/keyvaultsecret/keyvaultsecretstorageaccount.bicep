param storageAccountName string
param secretNameSegments string

// reference existing storage account...
resource storageaccountreference 'Microsoft.Storage/storageAccounts@2022-09-01' existing = {
  name: storageAccountName
}

// create a new secret @ '${keyVaultName}/${storageAccountName}'...
resource secret 'Microsoft.KeyVault/vaults/secrets@2019-09-01' = {
  name: secretNameSegments
  properties: {
    value: 'DefaultEndpointsProtocol=https;AccountName=${storageaccountreference.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storageaccountreference.listKeys().keys[0].value}'
  }
}
