param keyvaultName string = ''
param serviceBusApiVersion string = ''
param serviceBusId string = ''
param secretName string = ''

// reference the existing keyvault...
resource keyvault 'Microsoft.ServiceBus/namespaces@2023-01-01-preview' existing = {
  name: keyvaultName
}

var secretNameSegments = '${keyvault.name}/${secretName}'

// create a new secret @ '${keyvault.name}/${secretName}'...
resource secret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  name: secretNameSegments
  properties: {
    value: listKeys('${serviceBusId}/AuthorizationRules/RootManageSharedAccessKey', serviceBusApiVersion).primaryConnectionString
  }
}
