targetScope = 'subscription'

@description('Name of the budget.')
param budgetName string

@description('The time covered by a budget.')
@allowed([
  'Annually'
  'BillingAnnual'
  'BillingMonth'
  'BillingQuarter'
  'Monthly'
  'Quarterly'
])
param timegrain string

@description('Start date in the format yyyy-MM-dd')
param startDate string

@description('End date in the format yyyy-MM-dd')
param endDate string

@description('Maximum budget allowed')
param maximumBudget int

@description('Configure up to 5 notifications.')
param notifications object

var endDateDefault = empty(endDate) ? dateTimeAdd(startDate, 'P20Y') : endDate

resource budget 'Microsoft.Consumption/budgets@2021-10-01' = {
  name: budgetName
  properties: {
    category: 'Cost'
    amount: maximumBudget
    timeGrain: timegrain
    timePeriod: {
      startDate: startDate
      endDate: endDateDefault
    }
    notifications: notifications
  }
}
