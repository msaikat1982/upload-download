// https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachines/extensions?pivots=deployment-language-bicep

param location string
param vmName string
param extName string
param commandToExecute string

resource vm 'Microsoft.Compute/virtualMachines@2024-11-01' existing = {
  name: vmName
}

var isLinux = !empty(vm.properties.osProfile.linuxConfiguration)
var typeHandlerVersion = isLinux ? '2.1' : '1.10'

resource extension 'Microsoft.Compute/virtualMachines/extensions@2025-04-01' = {
  parent: vm
  name: extName
  location: location
  properties: {
    publisher: 'Microsoft.Azure.Extensions'
    type: 'CustomScript'
    typeHandlerVersion: typeHandlerVersion
    settings: {
      commandToExecute: commandToExecute
      }
      autoUpgradeMinorVersion: true
  }
}
