// Creates an Azure Container Registry

////////////////////////
// Default Parameters //
////////////////////////

// Registry...

@description('The value that indicates whether the admin user is enabled.')
param adminUserEnabled bool = false

@description('Enables registry-wide pull from unauthenticated clients.')
param anonymousPullEnabled bool = false

@description('Whether to allow trusted Azure services to access a network restricted registry.')
@allowed(['None', 'AzureServices'])
param networkRuleBypassOptions string = 'AzureServices'

@description('Whether or not public network access is allowed for the container registry.')
@allowed(['Disabled','Enabled'])
param publicNetworkAccess string = 'Enabled'

// Policies...

@description('The value that indicates whether the Export policy is enabled or not.')
@allowed(['disabled', 'enabled'])
param exportPolicyStatus string = 'enabled'

@description('The value that indicates whether the Quarantine policy is enabled or not.')
@allowed(['disabled', 'enabled'])
param quarantinePolicyStatus string = 'disabled'

@description('The value that indicates whether the Retention policy is enabled or not.')
@allowed(['disabled', 'enabled'])
param retentionPolicyStatus string = 'disabled'

@description('Retention: The number of days to retain an untagged manifest after which it gets purged.')
param retentionPolicyDays int = 0 

@description('The value that indicates whether the Soft Delete policy is enabled or not.')
@allowed(['disabled', 'enabled'])
param softDeletePolicyStatus string = 'enabled'

@description('The number of days after which a soft-deleted item is permanently deleted.')
param softDeleteRetentionDays int = 14

@description('The value that indicates whether the Trust policy is enabled or not.')
@allowed(['disabled', 'enabled'])
param trustPolicyStatus string = 'disabled'

@description('The type of trust policy.')
@allowed(['Notary'])
param trustPolicyType string = 'Notary'

/////////////////////////
// Required Parameters //
/////////////////////////

@description('Azure region of the deployment')
param location string

@description('Container registry name')
param containerRegistryName string
var containerRegistryNameCleaned = replace(containerRegistryName, '-', '')

@description('The SKU name of the container registry. Required for registry creation.')
@allowed(['Basic','Classic','Standard','Premium',])
param sku string = 'Premium'

@description('Tags to add to the resources')
param tags object = {}

///////////////////
// Resource Call //
///////////////////

resource containerRegistry 'Microsoft.ContainerRegistry/registries@2023-01-01-preview' = {
  name: containerRegistryNameCleaned
  location: location
  tags: tags
  sku: {
    name: sku
  }
  properties: {
    adminUserEnabled: adminUserEnabled
    networkRuleBypassOptions: networkRuleBypassOptions
    // networkRuleSet: {
    //   defaultAction: networkRuleSetdefaultAction
    //   ipRules: networkRuleSetIPRules
    // }
    policies: {
      exportPolicy: {
        status: exportPolicyStatus
      }
      quarantinePolicy: {
        status: quarantinePolicyStatus
      }
      retentionPolicy: {
        status: retentionPolicyStatus
        days: retentionPolicyDays
      }
      softDeletePolicy: {
        status: softDeletePolicyStatus
        retentionDays: softDeleteRetentionDays
      }
      trustPolicy: {
        status: trustPolicyStatus
        type: trustPolicyType
      }    
    }
    publicNetworkAccess: publicNetworkAccess
    zoneRedundancy: 'Disabled'
    anonymousPullEnabled: anonymousPullEnabled
    //dataEndpointEnabled: dataEndpointEnabled
    // encryption: {
      //status: encryptionStatus
      // keyVaultProperties: {
      //   identity: keyvaultClientIdentity
      //   keyIdentifier: keyvaultIdentifier
    //}
    // identity: {
      //principalId: principalId
      //tenantId: tenantId
      //type: identityType
      //userAssignedIdentities: userAssignedIdentities
    //}
  }
}

output containerRegistryId string = containerRegistry.id
output containerRegitryName string = containerRegistry.name

/////////////////////////
// Excluded Parameters //
/////////////////////////

// Identity...

// @description('The principal ID of resource identity.')
// param principalId string = ''

// @description('The tenant ID of resource identity.')
// param tenantId string = tenant().tenantId

// @description('The Identity type')
// @allowed(['None','SystemAssigned','SystemAssigned, UserAssigned','UserAssigned'])
// param identityType string = 'None'

// @description('The list of user identities associated with the resource. ')
// param userAssignedIdentities object = {}

// Registry...

// @description('Enable a single data endpoint per region for serving data.')
// param dataEndpointEnabled bool = false

// @description('The encryption settings of container registry.')
// @allowed(['disabled', 'enabled'])
// param encryptionStatus string = 'disabled'

// @description('Whether or not zone redundancy is enabled for this container registry')
// @allowed(['Disabled', 'Enabled'])
// param zoneRedundancy string = 'Enabled'

// Encryption...

// @description('The client id of the identity which will be used to access key vault.')
// param keyvaultClientIdentity string = ''

// @description('Key vault uri to access the encryption key.')
// param keyvaultIdentifier string = ''

// Network

// @description('The default NetworkRuleSet action of allow or deny when no other rules match.')
// param networkRuleSetdefaultAction string = 'Deny'

// @description('The action of IP ACL rule')
// param networkRuleSetIPRules array = []
