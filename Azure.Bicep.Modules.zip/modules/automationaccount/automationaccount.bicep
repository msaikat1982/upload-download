param accountName string
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string
param subnetId string
param tags object

resource automationaccount 'Microsoft.Automation/automationAccounts@2023-11-01' = {
  name: accountName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    disableLocalAuth: false
    // encryption: {
    //   identity: {
    //     userAssignedIdentity:
    //   }
    //   keySource: 'string'
    //   keyVaultProperties: {
    //     keyName: 'string'
    //     keyvaultUri: 'string'
    //     keyVersion: 'string'
    //   }
    // }
    publicNetworkAccess: false
    sku: {
      capacity: null
      family: null
      name: 'Basic'
    }
  }
  tags: tags
}

output automationAccountName string = automationaccount.name
output automationAccountId string = automationaccount.id

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module aaPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'aa-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: automationaccount.id
    pvtEpName: '${automationaccount.name}-pvtep'
    location: location
    groupdId: 'Webhook'
    privateDnsZone: 'privatelink.azure-automation.net'
  }
}

