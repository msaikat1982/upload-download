@description('Name of the Data Factory')
@minLength(3)
@maxLength(63)
param dataFactoryName string

@description('Azure Region to deploy Data Factory')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Environment for Key Vault')
@allowed(['poc','dev','tst','stg','prd'])
param env string

@description('Map [env] to an Azure resource tag')
var envMap = {
  poc: 'poc'
  dev: 'Develop'
  tst: 'Test'
  stg: 'Stage'
  prd: 'Production'
}
var envTag = envMap[env]
var tag = {Environment: envTag}

@description('Azure resource tags provided as key/value object')
param tags object = {}

@allowed(['SystemAssigned','UserAssigned','SystemAssigned,UserAssigned'])
@description('Type of managed identity')
param identityType string = 'SystemAssigned'

@description('Git Repo Configuration Object')
param repoConfiguration object = {}
// Example Object:
// {
//   accountName: ''
//   repositoryName: ''
//   collaborationBranch: ''
//   rootFolder: ''
//   type: ''
//   disablePublish: true
// }

@description('Map location of ADF to the correct eventhub Auth rule')
var eventHubAuthMap = {
  centralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-c-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  eastus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-e-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  northcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Ops0-DCRG/providers/Microsoft.EventHub/namespaces/net0-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
  southcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/OPS1-DCRG/providers/Microsoft.EventHub/namespaces/net1-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
}

@description('Based on location of ADF, use eventHub in that region. This is the Auth Rule or SAS token to use')
var eventHubAuthRuleId = eventHubAuthMap[location]

@description('Map eventHubName namespace to the eventHub name within the namespace')
var eventHubNameMap = {
  centralus: 'insights-operational-logs'
  eastus: 'insights-operational-logs'
  northcentralus: 'insights-operational-logs'
  southcentralus: 'insights-operational-logs'
}

@description('Map the location of the ADF to the proper eventhub in the eventhub namespace')
var eventHubName = eventHubNameMap[location]

@description('Name the ADF Managed vNet')
var managedVnetName = 'default'

@description('Name the managed Integration Runtime') 
// Using the name 'AutoResolveIntegrationRuntime', your deployment will take the place of the default ADF integration runtime.
// Using any other name will create a second integration runtime that will be public.
var managedIntegrationRuntimeName = 'AutoResolveIntegrationRuntime'

@description('Enable Managed Virtual Network')
param enableManagedVirtualNetwork bool = true

@description('Enable the integration runtime inside the managed virtual network. Only required if enableManagedVirtualNetwork is true')
param enableManagedVnetIntegrationRuntime bool = true

// Data Factory
resource azureDataFactory 'Microsoft.DataFactory/factories@2018-06-01' = {
  name: dataFactoryName
  location: location
  tags: union(tag,tags)
  identity: {
    type: identityType
  }
  properties: {
    publicNetworkAccess: 'Disabled'
    repoConfiguration: repoConfiguration
  }
}

// Managed vNet
resource managedVirtualNetwork 'Microsoft.DataFactory/factories/managedVirtualNetworks@2018-06-01' = if (enableManagedVirtualNetwork) {
  name: managedVnetName
  parent: azureDataFactory
  properties: {}
}

// Managed IR
resource managedIntegrationRuntime 'Microsoft.DataFactory/factories/integrationRuntimes@2018-06-01' = if (enableManagedVnetIntegrationRuntime) {
  name: managedIntegrationRuntimeName
  parent: azureDataFactory
  properties: {
    type: 'Managed'
    managedVirtualNetwork: {
      referenceName: managedVnetName
      type: 'ManagedVirtualNetworkReference'
    }
    typeProperties: {
      computeProperties: {
        location: 'AutoResolve'
      }
    }
  }
  dependsOn: [
    managedVirtualNetwork
  ]
}

// Create Diagnostic Settings for the Data Factory - Send logs to Event Hub to be ingested by splunk
resource adfDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${dataFactoryName}-diag'
  scope: azureDataFactory
  properties: {
    eventHubAuthorizationRuleId: eventHubAuthRuleId
    eventHubName: eventHubName
    logs: [
      {
        category: 'ActivityRuns'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'PipelineRuns'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'TriggerRuns'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SandboxPipelineRuns'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SandboxActivityRuns'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISPackageEventMessages'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISPackageExecutableStatistics'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISPackageEventMessageContext'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISPackageExecutionComponentPhases'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISPackageExecutionDataStatistics'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'SSISIntegrationRuntimeLogs'
        categoryGroup: null
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: 'AirflowTaskLogs'
        categoryGroup: null
        enabled: false
        retentionPolicy: {
            days: 0
            enabled: false
        }
      }
      {
        category: 'AirflowWorkerLogs'
        categoryGroup: null
        enabled: false
        retentionPolicy: {
            days: 0
            enabled: false
        }
      }
      {
        category: 'AirflowDagProcessingLogs'
        categoryGroup: null
        enabled: false
        retentionPolicy: {
            days: 0
            enabled: false
        }
      }
      {
        category: 'AirflowSchedulerLogs'
        categoryGroup: null
        enabled: false
        retentionPolicy: {
            days: 0
            enabled: false
        }
      }
      {
        category: 'AirflowWebLogs'
        categoryGroup: null
        enabled: false
        retentionPolicy: {
            days: 0
            enabled: false
        }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
        timeGrain: 'string'
      }
    ]
  }
}

// output the name  and id of the data factory resource once it has been created...
output dataFactoryResourceName string = azureDataFactory.name
output dataFactoryResourceId string = azureDataFactory.id
output dataFactoryResourceManagedIdentity string = azureDataFactory.identity.principalId

// Private Endpoints...

param subnetId string

// Module call to create Private Endpoints and Private Endpoint DNS for data factory...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module adfPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'adf-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: azureDataFactory.id
    pvtEpName: '${azureDataFactory.name}-pvtep'
    location: location
    groupdId: 'dataFactory'
    privateDnsZone: 'privatelink.datafactory.azure.net'
  }
}
