@description('Location for databricks workspace.')
param location string

@description('Name of databricks workspace.')
param name string

@description('SKU of databricks workspace.')
param skuName string

@description('Managed Resource Group Name for databricks workspace.')
param mrgName string

@description('Network details for databricks workspace. (VnetName, Private/Public Subnet Names) ')
param networkDetails object = {}

@description('Should Public IP be disabled for databricks workspace.')
param disablePublicIp bool

@allowed([
  'Enabled'
  'Disabled'
])
@description('Should Public Network Access be disabled for databricks workspace.')
param publicNetworkAccess string = 'Disabled'

@description('Azure resource tags provided as key/value pairs for databricks workspace.')
param tags object

@description('A timestamp for naming unique deployments.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

resource vnet 'Microsoft.Network/virtualNetworks@2022-07-01' existing = {
  name: networkDetails.vnetName
  scope: resourceGroup(networkDetails.vnetRGName)
}

module dbricksNsg 'br:gehabicep.azurecr.io/bicep/modules/databricksnsg:v1.0.0' = {
  name: 'dbricksNsg-${deploymentTimeStamp}'
  scope: resourceGroup(networkDetails.vnetRgName)
  params: {
    location: location
    nsgName: 'nsg-${name}'
    vnetName: networkDetails.vnetName
    vnetRgName: networkDetails.vnetRgName
    publicSubnet: networkDetails.publicSubnetName
    privateSubnet: networkDetails.privateSubnetName
  }
}

resource dbricks 'Microsoft.Databricks/workspaces@2024-09-01-preview' = {
  location: location
  dependsOn: [dbricksNsg]
  name: name
  sku: {
    name: skuName
  }
  properties: {
    managedResourceGroupId: '${subscription().id}/resourceGroups/${mrgName}'
    parameters: {
      customVirtualNetworkId: {
        value: vnet.id
      }
      customPublicSubnetName: {
        value: networkDetails.publicSubnetName
      }
      customPrivateSubnetName: {
        value: networkDetails.privateSubnetName
      }
      enableNoPublicIp: {
        value: disablePublicIp
      }
    }
    publicNetworkAccess: publicNetworkAccess
    requiredNsgRules: (disablePublicIp == true ? 'NoAzureDatabricksRules' : 'AllRules')
  }  
  tags: tags
}

param peSubnetId string = ''

@allowed([
  ''
  'eus'
  'cus'
  'ncus'
  'scus'
])
param regionalAuthPELoc string = ''

param regionalAuthPE array = [
  {
    name: '${name}-${regionalAuthPELoc}-auth-pvtep'
    groupId: 'browser_authentication'
    pvtDnsZone: 'privatelink.azuredatabricks.net'
  }
]

param dbricksPvtEndpts array = [
  {
    name: '${name}-backend-pvtep'
    groupId: 'databricks_ui_api'
    pvtDnsZone: 'privatelink.azuredatabricks.net'
  }
  {
    name: '${name}-frontend-pvtep'
    groupId: 'databricks_ui_api'
    pvtDnsZone: 'privatelink.azuredatabricks.net'
  }
]

param pvtEndpts array = ((!empty(regionalAuthPELoc) ? union(dbricksPvtEndpts, regionalAuthPE) : dbricksPvtEndpts))

@batchSize(1)
module dbricksPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.2' = [for pe in pvtEndpts: if (!empty(peSubnetId)) {
//module appSrvPvtEp '../modules/privateendpoint.bicep' = if (!empty(subnetId)) {
  name: '${pe.name}-${deploymentTimeStamp}'
  params: {
    subnetId: peSubnetId
    resourceId: dbricks.id
    pvtEpName: pe.name
    location: location
    groupdId: pe.groupId
    privateDnsZones: [
      pe.pvtDnsZone
    ]
  }
}]

// Diagnostic Settings
// This resource is used to set up diagnostic settings for Databricks

param dbricksLogs array

param dbricksMetrics array

param workspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'

resource diagSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${name}-diag'
  scope: dbricks
  properties: {
    workspaceId: workspaceId
    logs: dbricksLogs
    metrics: dbricksMetrics
  }
}
