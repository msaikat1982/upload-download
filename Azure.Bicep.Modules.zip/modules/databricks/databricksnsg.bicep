param location string
param nsgName string
param vnetName string
param vnetRgName string
param publicSubnet string
param privateSubnet string
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

//create the nsg...
resource nsg 'Microsoft.Network/networkSecurityGroups@2024-05-01' = {
  name: nsgName
  location: location
  properties: {
    securityRules: [
      {
        name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-worker-inbound'
        properties: {
          description: 'Required for worker nodes communication within a cluster.'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'VirtualNetwork'
          access: 'Allow'
          priority: 100
          direction: 'Inbound'
        }
      }
      {
        name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-worker-outbound'
        properties: {
          description: 'Required for worker nodes communication within a cluster.'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'VirtualNetwork'
          access: 'Allow'
          priority: 100
          direction: 'Outbound'
        }
      }
      {
        name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-sql'
        properties: {
          description: 'Required for workers communication with Azure SQL services.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '3306'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'Sql'
          access: 'Allow'
          priority: 101
          direction: 'Outbound'
        }
      }
      {
        name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-storage'
        properties: {
          description: 'Required for workers communication with Azure Storage services.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '443'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'Storage'
          access: 'Allow'
          priority: 102
          direction: 'Outbound'
        }
      }
      {
        name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-eventhub'
        properties: {
          description: 'Required for worker communication with Azure Eventhub services.'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '9093'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: 'EventHub'
          access: 'Allow'
          priority: 103
          direction: 'Outbound'
        }
      }
    ]
        // {
        //   name: 'Microsoft.Databricks-workspaces_UseOnly_databricks-worker-to-databricks-cp'
        //   properties: {
        //     description: 'Required for workers communication with Databricks control plane.'
        //     protocol: 'Tcp'
        //     sourcePortRange: '*'
        //     destinationPortRanges: ['443','8443-8451','3306']
        //     sourceAddressPrefix: 'VirtualNetwork'
        //     destinationAddressPrefix: 'AzureDatabricks'
        //     access: 'Allow'
        //     priority: 100
        //     direction: 'Outbound'
        //   }
        // }
  }
}

output nsgId string = nsg.id

//get the existing dbricks vnet and the public and private subnets...
resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vnetName
  scope: resourceGroup(vnetRgName)
}

resource private 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  name: privateSubnet
  parent: vnet
}

resource public 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  name: publicSubnet
  parent: vnet
}

//use module calls to assign the nsg to the subnets. we use modules here because we cannot scope 'resource' write operations...
module assignNsg_private 'br:gehabicep.azurecr.io/bicep/modules/databricksnsgassign:v1.0.0' = {
  name: 'nsg-assign-priv-${deploymentTimeStamp}'
  scope: resourceGroup(vnetRgName)
  params:{
    vnetName: vnetName
    subnet: privateSubnet
    properties: union(private.properties, {
      networkSecurityGroup: {
        id: nsg.id
      }
    })
  }
}

module assignNsg_public 'br:gehabicep.azurecr.io/bicep/modules/databricksnsgassign:v1.0.0' = {
  name: 'nsg-assign-pub-${deploymentTimeStamp}'
  scope: resourceGroup(vnetRgName)
  params:{
    vnetName: vnetName
    subnet: publicSubnet
    properties: union(public.properties, {
      networkSecurityGroup: {
        id: nsg.id
      }
    })
  }
}
