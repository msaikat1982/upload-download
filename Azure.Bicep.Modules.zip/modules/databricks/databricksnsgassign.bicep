param vnetName string
param subnet string
param properties object

resource vnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: vnetName
}

resource public 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' = {
  name: subnet
  parent: vnet
  properties: properties
}
