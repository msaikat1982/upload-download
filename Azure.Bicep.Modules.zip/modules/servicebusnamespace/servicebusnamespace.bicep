// https://learn.microsoft.com/en-us/azure/templates/microsoft.servicebus/namespaces?pivots=deployment-language-bicep

// Deployment Parameters //

@description('Azure Region to deploy Service Bus')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Environment for Service Bus')
@allowed(['poc','dev','tst','stg','prd'])
param env string

@description('Azure resource tags provided as key/value object')
param tags object = {}

@description('Map [env] to an Azure resource tag')
var envMap = {
  poc: 'poc'
  dev: 'Develop'
  tst: 'Test'
  stg: 'Stage'
  prd: 'Production'
}
var envTag = envMap[env]
var tag = {Environment: envTag}

// Resource Parameters //

@description('The name of the Service Bus namespace')
@minLength(6)
@maxLength(50)
param serviceBusNamespaceName string

@description('Specifies the name of the SKU.')
@allowed(['Basic','Standard','Premium'])
param skuName string = 'Premium'

@description('Specifies the tier of the SKU.')
@allowed(['Basic','Standard','Premium'])
param skuTier string = 'Premium'

@description('Messaging units for your service bus premium namespace.')
param capacity int = 1

@description('Disables SAS authentication for the Service Bus namespace.')
param disableLocalAuth bool = false

@description('Specifies the number of partitions of a Service Bus namespace. This property is only applicable to Premium SKU namespaces.')
param premiumMessagingPartitions int = 0

@description('This determines if traffic is allowed over public network. By default it is enabled.')
@allowed(['Disabled','Enabled','SecuredByPerimeter'])
param publicNetworkAccess string = 'Disabled'

@description('Enabling this property creates a Premium Service Bus Namespace in regions supported availability zones.')
param zoneRedundant bool = false

resource servicebusnamespace 'Microsoft.ServiceBus/namespaces@2022-10-01-preview' = {
  name: serviceBusNamespaceName
  location: location
  tags: union(tag,tags)
  sku: {
    name: skuName
    tier: skuTier
    capacity: capacity
  }
  properties: {
    disableLocalAuth: disableLocalAuth
    minimumTlsVersion: '1.2'
    premiumMessagingPartitions: premiumMessagingPartitions
    publicNetworkAccess: publicNetworkAccess
    zoneRedundant: zoneRedundant
  }
}

// Output the name and id of the Service Bus Namespace...
output serviceBusNamespaceName string = servicebusnamespace.name
output serviceBusNamespaceId string = servicebusnamespace.id
output serviceBusNamespaceApiVersion string = servicebusnamespace.apiVersion

//Private Endpoints...

param subnetId string

// Module call to create Private Endpoints and Private Endpoint DNS for Service Bus...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module sbPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'sb-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: servicebusnamespace.id
    pvtEpName: '${servicebusnamespace.name}-pvtep'
    location: location
    groupdId: 'namespace'
    privateDnsZone: 'privatelink.servicebus.windows.net'
  }
}

// Diagnostics Settings: Event Hub

var eventHubNamespaceMap = {
  centralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-c-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  eastus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Shared-Resources/providers/Microsoft.EventHub/namespaces/gehaaz-e-eventhub-01/authorizationrules/RootManageSharedAccessKey'
  northcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/Ops0-DCRG/providers/Microsoft.EventHub/namespaces/net0-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
  southcentralus: '/subscriptions/f0bacc2a-12d2-4cd5-86f8-80d5a18fa89e/resourceGroups/OPS1-DCRG/providers/Microsoft.EventHub/namespaces/net1-gehaeventhub/authorizationrules/RootManageSharedAccessKey'
}

@description('Based on location of Service Bus, use eventHub in that region.')
var eventHubRuleId = eventHubNamespaceMap[location]

@description('Map eventHubName namespace to the eventHub name within the namespace')
var eventHubNameMap = {
  centralus: 'insights-operational-logs'
  eastus: 'insights-operational-logs'
  northcentralus: 'insights-operational-logs'
  southcentralus: 'insights-operational-logs'
}

@description('Get the Event Hub name from the appropriate namespace')
var eventHubName = eventHubNameMap[location]

resource serviceBusDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${servicebusnamespace.name}-diag'
  scope: servicebusnamespace
  properties: {
    eventHubAuthorizationRuleId: eventHubRuleId
    eventHubName: eventHubName
    logs: [
      {
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
    metrics: [
      {
        category: 'AllMetrics'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: true
        }
      }
    ]
  }
}
