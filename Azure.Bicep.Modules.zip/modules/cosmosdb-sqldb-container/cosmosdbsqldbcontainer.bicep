@description('The name of the Azure Cosmos DB SQL Container.')
param name string

@description('The location of the cosmosdb sql container.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Tags to apply to the Azure Cosmos DB SQL Container.')
param tags object = {}

@description('The name of the Azure Cosmos DB SQL Database.')
param cosmosAcctName string //temporary while debugging parent json syntax error

@description('The name of the Azure Cosmos DB SQL Database.')
param cosmosSqlDbName string

// @description('Analytical TTL')
// param analyticalStorageTtl int = -1

@description('Indicates the indexing mode.')
param indPol_mode string = 'Consistent'

@description('Indicates if the indexing policy is automatic.')
param indPol_isAutomatic bool = true

@description('List of paths to include in the indexing')
param indPol_includedPaths array = [
  {
    path: '/*'
  }
]

@description('List of paths to exclude from indexing')
param indPol_excludedPaths array = [
  {
    path: '/_etag/?'
  }
]
@description('List of paths using which data within the container can be partitioned.')
param partKey_paths array = []

@description('Indicates the kind of algorithm used for partitioning. For MultiHash, multiple partition keys (upto three maximum) are supported for container create')
param partKey_kind string = 'Hash'

@minValue(1)
@maxValue(2)
param partKey_version int = 2

@description('List of unique keys on that enforces uniqueness constraint on documents in the collection in the Azure Cosmos DB service.')
param uniqueKeys array = []

@description('Indicates the conflict resolution mode.')
@allowed([
  'LastWriterWins'
  'Custom'
])
param confResPol_mode string = 'LastWriterWins'

@description('The conflict resolution path in the case of LastWriterWins mode.')
param conflictResolutionPathOrProcedure string = '/_ts'

@minValue(400)
@maxValue(1000000)
@description('The throughput for the container')
param throughput int = 400

// resource sqlDb 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2024-05-15' existing = {
//   name: cosmosSqlDbName
// }

resource sqlContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2024-05-15' = {
  name: '${cosmosAcctName}/${cosmosSqlDbName}/${name}'
  location: location
  tags: tags
  //parent: sqlDb
  properties: {
    options: {
      throughput: throughput
    }
    resource: {
      id: name
      indexingPolicy: {
        indexingMode: indPol_mode
        automatic: indPol_isAutomatic
        includedPaths: indPol_includedPaths
        excludedPaths: indPol_excludedPaths
      }
      partitionKey: {
        paths: partKey_paths
        kind: partKey_kind
        version: partKey_version
      }
      uniqueKeyPolicy: {
        uniqueKeys: uniqueKeys
      }
      conflictResolutionPolicy: {
        mode: confResPol_mode
        conflictResolutionPath: (confResPol_mode == 'LastWriterWins' ? conflictResolutionPathOrProcedure : '')
        conflictResolutionProcedure: (confResPol_mode == 'Custom' ? conflictResolutionPathOrProcedure : '')
      }
    }    
  }
}

output sqlContainerResourceName string = sqlContainer.name
output sqlContainerResourceId string = sqlContainer.id
