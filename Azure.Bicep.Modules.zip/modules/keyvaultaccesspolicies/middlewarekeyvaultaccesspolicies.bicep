param keyVaultName string
param tenantId string
param env string

//dev policy set...
param accessPoliciesDev array = [
  {
      objectId: 'd0cbb394-af16-4271-ad35-baddc3c9993b' // Azure_Middleware_EIS_Devs
      tenantId: tenantId
      permissions: {
          keys: [
              'list'
          ]
          secrets: [
              'list'
          ]
          certificates: [
              'list'
          ]
      }
  }
  {
      objectId: 'b1cc201f-72a9-4754-bbbf-714c6007640f' // Azure_Middleware_EIS_Devs-Admin
      tenantId: tenantId
      permissions: {
          keys: [
              'get'
              'list'
              'update'
              'create'
              'import'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
              'release'
          ]
          secrets: [
              'get'
              'list'
              'set'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
          ]
          certificates: [
              'get'
              'list'
              'update'
              'create'
              'import'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
          ]
      }
  }
  {
      objectId: '7904b2f0-7f3e-47b3-9ecd-19e52d0a7c6c' // Azure_Middleware_EIS_Analysts
      tenantId: tenantId
      permissions: {
          keys: [
              'list'
          ]
          secrets: [
              'list'
          ]
          certificates: [
              'list'
          ]
      }
  }
  {
      objectId: '4dc1e773-a816-4566-a8ad-2678455c3269' // Azure_Middleware_EIS_Analysts-Admin
      tenantId: tenantId
      permissions: {
          keys: [
              'get'
              'list'
              'update'
              'create'
              'import'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
              'release'
          ]
          secrets: [
              'get'
              'list'
              'set'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
          ]
          certificates: [
              'get'
              'list'
              'update'
              'create'
              'import'
              'delete'
              'recover'
              'backup'
              'restore'
              'purge'
          ]
      }
  }
  {
    objectId: '6e257972-cdd9-48d7-a602-f405f4e461c2'    //azurekeyvaultsecretsprovider-geha-dev-aks
    tenantId: tenantId
    permissions: {
      keys: [
        'get'
        'list'
      ]
      secrets: [
        'get'
        'list'
      ]
      certificates: [
        'get'
        'list'      
      ]
    }
   }
   {
    objectId: 'b7ae8e71-33e6-48d7-83ac-3903cff243ca'    //Azure_Middleware_QA : 
    tenantId: tenantId
    permissions: {
      keys: [
        'list'
      ]
      secrets: [
        'list'
      ]
      certificates: [
        'list'      
      ]
    }
   }
   {
    objectId: 'f888d6a5-f10d-4b9d-828a-f4c9dacd013e'    //Azure_Middleware_QA-admin 
    tenantId: tenantId
    permissions: {
      keys: [
        'get'
        'list'
      ]
      secrets: [
        'get'
        'list'
      ]
      certificates: [
        'get'
        'list'      
      ]
    }
   }
]

//tst policy set...
param accessPoliciesTst array = [
  {
    objectId: 'd0cbb394-af16-4271-ad35-baddc3c9993b' // Azure_Middleware_EIS_Devs
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: 'b1cc201f-72a9-4754-bbbf-714c6007640f' // Azure_Middleware_EIS_Devs-Admin
    tenantId: tenantId
    permissions: {
        keys: [
          'get'
          'list'
          'update'
          'create'
          'import'
          'delete'
          'recover'
          'backup'
          'restore'
          'purge'
          'release'
        ]
        secrets: [
          'get'
          'list'
          'set'
          'delete'
          'recover'
          'backup'
          'restore'
          'purge'
        ]
        certificates: [
          'get'
          'list'
          'update'
          'create'
          'import'
          'delete'
          'recover'
          'backup'
          'restore'
          'purge'
        ]
    }
}
{
    objectId: '7904b2f0-7f3e-47b3-9ecd-19e52d0a7c6c' // Azure_Middleware_EIS_Analysts
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: '4dc1e773-a816-4566-a8ad-2678455c3269' // Azure_Middleware_EIS_Analysts-Admin
    tenantId: tenantId
    permissions: {
        keys: [
            'get'
            'list'
            'update'
            'create'
            'import'
            'delete'
            'recover'
            'backup'
            'restore'
            'purge'
            'release'
        ]
        secrets: [
            'get'
            'list'
            'set'
            'delete'
            'recover'
            'backup'
            'restore'
            'purge'
        ]
        certificates: [
            'get'
            'list'
            'update'
            'create'
            'import'
            'delete'
            'recover'
            'backup'
            'restore'
            'purge'
        ]
    }
}
{
  objectId: '6e257972-cdd9-48d7-a602-f405f4e461c2'    //azurekeyvaultsecretsprovider-geha-dev-aks
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
    ]
    secrets: [
      'get'
      'list'
    ]
    certificates: [
      'get'
      'list'      
    ]
  }
 }
 {
  objectId: 'b7ae8e71-33e6-48d7-83ac-3903cff243ca'    //Azure_Middleware_QA : 
  tenantId: tenantId
  permissions: {
    keys: [
      'list'
    ]
    secrets: [
      'list'
    ]
    certificates: [
      'list' 
    ]
  }
 }
 {
  objectId: 'f888d6a5-f10d-4b9d-828a-f4c9dacd013e'    //Azure_Middleware_QA-admin 
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
      'update'
      'create'
      'import'
      'delete'
      'recover'
      'backup'
      'restore'
      'purge'
      'release'
  ]
  secrets: [
      'get'
      'list'
      'set'
      'delete'
      'recover'
      'backup'
      'restore'
      'purge'
  ]
  certificates: [
      'get'
      'list'
      'update'
      'create'
      'import'
      'delete'
      'recover'
      'backup'
      'restore'
      'purge'
  ]
  }
 }
]

//stg policy set...
param accessPoliciesStg array = [
  {
    objectId: 'd0cbb394-af16-4271-ad35-baddc3c9993b' // Azure_Middleware_EIS_Devs
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: 'b1cc201f-72a9-4754-bbbf-714c6007640f' // Azure_Middleware_EIS_Devs-Admin
    tenantId: tenantId
    permissions: {
        keys: [
            'get'
            'list'
        ]
        secrets: [
            'get'
            'list'
        ]
        certificates: [
            'get'
            'list'
        ]
    }
}
{
    objectId: '7904b2f0-7f3e-47b3-9ecd-19e52d0a7c6c' // Azure_Middleware_EIS_Analysts
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: '4dc1e773-a816-4566-a8ad-2678455c3269' // Azure_Middleware_EIS_Analysts-Admin
    tenantId: tenantId
    permissions: {
        keys: [
            'get'
            'list'
        ]
        secrets: [
            'get'
            'list'
        ]
        certificates: [
            'get'
            'list'
        ]
    }
}
{
  objectId: '6e257972-cdd9-48d7-a602-f405f4e461c2'    //azurekeyvaultsecretsprovider-geha-dev-aks
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
    ]
    secrets: [
      'get'
      'list'
    ]
    certificates: [
      'get'
      'list'      
    ]
  }
 }
 {
  objectId: 'b7ae8e71-33e6-48d7-83ac-3903cff243ca'    //Azure_Middleware_QA : 
  tenantId: tenantId
  permissions: {
    keys: [
      'list'
    ]
    secrets: [
      'list'
    ]
    certificates: [
      'list'      
    ]
  }
 }
 {
  objectId: 'f888d6a5-f10d-4b9d-828a-f4c9dacd013e'    //Azure_Middleware_QA-admin 
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
    ]
    secrets: [
      'get'
      'list'
    ]
    certificates: [
      'get'
      'list'      
    ]
  }
 }
]

//prd policy set...
param accessPoliciesPrd array = [
  {
    objectId: 'd0cbb394-af16-4271-ad35-baddc3c9993b' // Azure_Middleware_EIS_Devs
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: 'b1cc201f-72a9-4754-bbbf-714c6007640f' // Azure_Middleware_EIS_Devs-Admin
    tenantId: tenantId
    permissions: {
        keys: [
            'get'
            'list'
        ]
        secrets: [
            'get'
            'list'
        ]
        certificates: [
            'get'
            'list'
        ]
    }
}
{
    objectId: '7904b2f0-7f3e-47b3-9ecd-19e52d0a7c6c' // Azure_Middleware_EIS_Analysts
    tenantId: tenantId
    permissions: {
        keys: [
            'list'
        ]
        secrets: [
            'list'
        ]
        certificates: [
            'list'
        ]
    }
}
{
    objectId: '4dc1e773-a816-4566-a8ad-2678455c3269' // Azure_Middleware_EIS_Analysts-Admin
    tenantId: tenantId
    permissions: {
        keys: [
            'get'
            'list'
        ]
        secrets: [
            'get'
            'list'
        ]
        certificates: [
            'get'
            'list'
        ]
    }
}
{
  objectId: '6e257972-cdd9-48d7-a602-f405f4e461c2'    //azurekeyvaultsecretsprovider-geha-dev-aks
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
    ]
    secrets: [
      'get'
      'list'
    ]
    certificates: [
      'get'
      'list'      
    ]
  }
 }
 {
  objectId: 'b7ae8e71-33e6-48d7-83ac-3903cff243ca'    //Azure_Middleware_QA : 
  tenantId: tenantId
  permissions: {
    keys: [
      'list'
    ]
    secrets: [
      'list'
    ]
    certificates: [
      'list'      
    ]
  }
 }
 {
  objectId: 'f888d6a5-f10d-4b9d-828a-f4c9dacd013e'    //Azure_Middleware_QA-admin 
  tenantId: tenantId
  permissions: {
    keys: [
      'get'
      'list'
    ]
    secrets: [
      'get'
      'list'
    ]
    certificates: [
      'get'
      'list'      
    ]
  }
 }
]

@description('Map [env] to a policy set.')
var policyMap = {
  dev: accessPoliciesDev
  tst: accessPoliciesTst
  stg: accessPoliciesStg
  prd: accessPoliciesPrd
}
var policySet = policyMap[env]

resource accessPolicies 'Microsoft.KeyVault/vaults/accessPolicies@2021-10-01' = {
  name: '${keyVaultName}/add'
  properties: {
    accessPolicies: [for accessPolicy in policySet: {
        tenantId: accessPolicy.tenantId
        objectId: accessPolicy.objectId
        permissions: {
          keys: accessPolicy.permissions.keys
          secrets: accessPolicy.permissions.secrets
          certificates: accessPolicy.permissions.certificates
        }
      }
    ]
  }
}
