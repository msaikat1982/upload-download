param keyVaultName string
param accessPoliciesConfig array

resource accessPolicies 'Microsoft.KeyVault/vaults/accessPolicies@2021-10-01' = {
  name: '${keyVaultName}/add'
  properties: {
    accessPolicies: [for accessPolicy in accessPoliciesConfig: {
        tenantId: accessPolicy.tenantId
        objectId: accessPolicy.objectId
        permissions: {
          keys: accessPolicy.permissions.keys
          secrets: accessPolicy.permissions.secrets
          certificates: accessPolicy.permissions.certificates
        }
      }
    ]
  }
}

