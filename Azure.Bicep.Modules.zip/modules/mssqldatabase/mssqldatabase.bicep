// Required Params

@description('The location of the Azure SQL Server.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('The name of the Azure SQL Server. This is the parent resource')
param sqlServerName string

@description('The name of the Azure SQL Database.')
param name string

// Optional Params

@description('Tags to apply to the Azure SQL Database.')
param tags object = {}

// To list available editions and SKUs for Azure SQL Database, you can use the Azure CLI command:
// az sql db list-editions --location eastus -o table
@description('The SKU of the Azure SQL Database.')
param sku object = {
  name: 'GP_S_Gen5' // General Purpose, Serverless
  tier: 'GeneralPurpose'
  family: 'Gen5'
  capacity: 1 // max # of vCores
}

@description('Maximum size of the database in GB.')
param max_size_gb int = 32 // Maximum size of the database in GB

@description('Enable read-only routing.')
@allowed(['Disabled', 'Enabled'])
param read_scale string = 'Disabled'

@description('Auto-pause delay in minutes. Set to -1 to disable auto-pause.')
param autoPauseDelay int = 60

@description('Requested backup storage redundancy.')
@allowed(['Local', 'Zone', 'Geo', 'GeoZone'])
param requestedBackupStorageRedundancy string = 'Zone'

// Define the SQL Server resource that will act as the parent for the SQL Database
resource sqlServer 'Microsoft.Sql/servers@2024-05-01-preview' existing = {
  name: sqlServerName
}

resource sqlDatabase 'Microsoft.Sql/servers/databases@2024-05-01-preview' = {
  parent: sqlServer  // Direct reference to the SQL Server resource
  name: name
  location: location
  tags: tags
  sku: sku
  properties: {
    collation: 'SQL_Latin1_General_CP1_CI_AS'
    maxSizeBytes: max_size_gb * 1024 * 1024 * 1024
    catalogCollation: 'SQL_Latin1_General_CP1_CI_AS'
    zoneRedundant: true
    readScale: read_scale
    autoPauseDelay: autoPauseDelay
    requestedBackupStorageRedundancy: requestedBackupStorageRedundancy
    minCapacity: json('0.5') // add as var/param later
    isLedgerOn: false
    availabilityZone: 'NoPreference'
  }
}

resource retentionPolicy 'Microsoft.Sql/servers/databases/backupShortTermRetentionPolicies@2024-05-01-preview' = {
  parent: sqlDatabase
  name: 'Default' // must be Default
  properties: {
    retentionDays: 30
    diffBackupIntervalInHours: 12
  }
}

// Diagnostic Settings not configured since they are 
// controlled with Azure Policy via Azure Landing Zone.

output sql_database_resource_id string = sqlDatabase.id

