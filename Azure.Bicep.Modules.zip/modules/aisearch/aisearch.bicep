// Parameters

@description('The name of the AI Search Engine.')
param name string

@description('The location of the AI Search Engine.')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('Azure resource tags provided as key/value object.')
param tags object = {}

@allowed([
  'basic'
  'free'
  'standard'
  'standard2'
  'standard3'
  'storage_optimized_l1'
  'storage_optimized_l2'
])
@description('The name of the SKU of the search service.')
param skuName string = 'standard'

@description('The type of identity used for the search service.')
param identityType string = 'SystemAssigned'

@allowed([
  'disabled'
  'free'
  'standard'
])
@description('Sets options that control the availability of semantic search..')
param semanticSearch string = 'standard'

@allowed([
  'disabled'
])
@description('Property to allow or block all public traffic for the App Service.')
param publicNetworkAccess string = 'disabled'

@allowed([
  'http401WithBearerChallenge'
  'http403'
])
@description('Describes what response the data plane API of a search service would send for requests that failed authentication.')
param aadAuthFailureMode string = 'http401WithBearerChallenge'

@description('When set to true, calls to the search service will not be permitted to utilize API keys for authentication.')
param disableLocalAuth bool = false

// Resource Call
resource aiSearch 'Microsoft.Search/searchServices@2024-03-01-preview' = {
  name: name
  location: location
  tags: tags
  sku: {
    name: skuName
  }
  identity: {
    type: identityType
  }
  properties: {
    authOptions: {
      aadOrApiKey: {
        aadAuthFailureMode: aadAuthFailureMode
      }
      // apiKeyOnly: any()
    }
    disableLocalAuth: disableLocalAuth
    publicNetworkAccess: publicNetworkAccess
    semanticSearch: semanticSearch
  }
}

output aiSearchResourceId string = aiSearch.id
output aiSearchName string = aiSearch.name

//Private Endpoints...

param subnetId string

// Module call to create Private Endpoints and Private Endpoint DNS for AI Search Service...
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module srchPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = if (!empty(subnetId)) {
  name: 'aiSearch-PvtEp-${deploymentTimeStamp}'
  params: {
    subnetId: subnetId
    resourceId: aiSearch.id
    pvtEpName: '${aiSearch.name}-pvtep'
    location: location
    groupdId: 'searchService'
    privateDnsZone: 'privatelink.search.windows.net'
  }
}

/////////////////////////
// Diagnostic Settings //
/////////////////////////

// Create Diagnostic Settings for AI Search - Send logs to central log analytics workspace
@description('The log analytics workspace ID for diagnostic settings')
param defaultLogAnalyticsWorkspaceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'
resource aiSearchDiagnosticSettings 'Microsoft.Insights/diagnosticSettings@2021-05-01-preview' = {
  name: '${aiSearch.name}-diag'
  scope: aiSearch
  properties: {
    // logAnalyticsDestinationType: null
    workspaceId: defaultLogAnalyticsWorkspaceId
    metrics: []
    logs: [
      {
        category: null
        categoryGroup: 'audit'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
      {
        category: null
        categoryGroup: 'allLogs'
        enabled: true
        retentionPolicy: {
          days: 0
          enabled: false
        }
      }
    ]
  }
}
