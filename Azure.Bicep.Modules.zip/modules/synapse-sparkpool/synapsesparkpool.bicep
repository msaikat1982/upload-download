param syn_name string

param name string

param location string

param tags object

param autopause_enabled bool = true

param autopause_delay int = 15

param autoscale_enabled bool = false

param autoscale_maxNodes int = 10

param autoscale_minNodes int = 3

param defaultLogFolder string = 'SparkLogs'

param dynExe_enabled bool = false

param dynExe_max int = 3

param dynExe_min int = 1

param autotune_enabled bool = false

param compIso_enabled bool = false

param nodeCount int = 3

@allowed([
  'Large'
  'Medium'
  'None'
  'Small'
  'XLarge'
  'XXLarge'
  'XXXLarge'
])
param nodeSize string

@allowed([
  'HardwareAcceleratedFPGA'
  'HardwareAcceleratedGPU'
  'MemoryOptimized'
  'None'
])
param nodeFamily string

param sessLevPkgs_enabled bool = false

param sparkEventsFolder string = 'SparkEvents'

param version string

resource synapse 'Microsoft.Synapse/workspaces@2021-06-01' existing = {
  name: syn_name 
}

resource spark 'Microsoft.Synapse/workspaces/bigDataPools@2021-06-01' = {
  name: name
  location: location
  tags: tags
  parent: synapse
  properties: {
    autoPause: {
      delayInMinutes: ((autopause_enabled == true) ? autopause_delay : null)
      enabled: autopause_enabled
    }
    autoScale: {
      enabled: autoscale_enabled
      maxNodeCount: ((autoscale_enabled == true) ? autoscale_maxNodes : null)
      minNodeCount: ((autoscale_enabled == true) ? autoscale_minNodes : null)
    }
    defaultSparkLogFolder: defaultLogFolder
    dynamicExecutorAllocation: {
      enabled: dynExe_enabled
      maxExecutors: ((dynExe_enabled == true) ? dynExe_max : null)
      minExecutors: ((dynExe_enabled == true) ? dynExe_min : null)
    }
    isAutotuneEnabled: autotune_enabled
    isComputeIsolationEnabled: compIso_enabled
    nodeCount: nodeCount
    nodeSize: nodeSize
    nodeSizeFamily: nodeFamily
    sessionLevelPackagesEnabled: sessLevPkgs_enabled
    sparkEventsFolder: sparkEventsFolder
    sparkVersion: version
  }
}
