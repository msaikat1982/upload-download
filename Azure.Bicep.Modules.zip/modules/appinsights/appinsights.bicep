// Creates an Azure Insights/components resource

////////////////////////
// Default Parameters //
////////////////////////

@description('Type of application being monitored.')
param Application_Type string = 'web'

@description('The kind of application that this component refers to, used to customize UI')
@allowed(['web', 'other'])
param kind string = 'web'

@description('Resource Id of the log analytics workspace which the data will be ingested to. This property is required to create an application with this API version. Applications from older versions will not have this property.')
param WorkspaceResourceId string = '/subscriptions/9d384ad6-3b86-4df1-9716-7ec131bd90ff/resourceGroups/rg-alz-logging/providers/Microsoft.OperationalInsights/workspaces/alz-log-analytics'

/////////////////////////
// Required Parameters //
/////////////////////////

@description('Azure region of the deployment')
param location string

@description('AppInsight name')
param appInsightName string

@description('Azure Resource Tags for the new resource.')
param tags object = {}

///////////////////
// Resource Call //
///////////////////

resource appInsight 'Microsoft.Insights/components@2020-02-02' = {
  name: appInsightName
  location: location
  tags: tags
  kind: kind
  properties: {
    Application_Type: Application_Type
    //DisableIpMasking: DisableIpMasking
    //DisableLocalAuth: DisableLocalAuth
    //Flow_Type: 'Bluefield'
    //ForceCustomerStorageForProfiler: ForceCustomerStorageForProfiler
    //HockeyAppId: HockeyAppId
    //ImmediatePurgeDataOn30Days: ImmediatePurgeDataOn30Days
    //IngestionMode: IngestionMode
    //publicNetworkAccessForIngestion: publicNetworkAccessForIngestion
    //publicNetworkAccessForQuery: publicNetworkAccessForQuery
    //Request_Source: 'rest'
    //RetentionInDays: RetentionInDays
    //SamplingPercentage: SamplingPercentage
    WorkspaceResourceId: WorkspaceResourceId
  }
}

output appInsightId string = appInsight.id
output appInsightName string = appInsight.name

/////////////////////////
// Excluded Parameters //
/////////////////////////

// @description('Disable IP masking')
// param DisableIpMasking bool = false

// @description('Disable Non-AAD based Auth.')
// param DisableLocalAuth bool = false

// @description('Used by the Application Insights system to determine what kind of flow this component was created by. This is to be set to "Bluefield" when creating/updating a component via the REST API.')
// param Flow_Type string = 'Bluefield'

// @description('Force users to create their own storage account for profiler and debugger.')
// param ForceCustomerStorageForProfiler bool = false

// @description('The unique application ID created when a new application is added to HockeyApp, used for communications with HockeyApp.')
// param HockeyAppId string = ''

// @description('Purge data immediately after 30 days.')
// param ImmediatePurgeDataOn30Days bool = false

// @description('The network access type for accessing Application Insights ingestion.')
// @allowed(['Disabled','Enabled'])
// param publicNetworkAccessForIngestion string = 'Enabled'

// @description('The network access type for accessing Application Insights query.')
// @allowed(['Disabled','Enabled'])
// param publicNetworkAccessForQuery string = 'Disabled'

// @description('Retention period in days.')
// param RetentionInDays int = 1

// @description('Percentage of the data produced by the application being monitored that is being sampled for Application Insights telemetry. To specify a decimal value, use the json() function.')
// param SamplingPercentage = null
