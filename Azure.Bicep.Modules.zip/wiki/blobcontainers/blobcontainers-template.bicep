//////////////////////
// REQUIRED PARAMETERS
//////////////////////

//Specifies the Azure storage account where you would like to add a container
param storageAccountName string = ''

//Specifies a name for each blob container you want to create. Provide container names in quotes, like 'container1','container2'
param containerNames array = [

]

//////////////////////
// OPTIONAL PARAMETERS
//////////////////////

//////////////
// CALL MODULE
//////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module ct 'br:gehabicep.azurecr.io/bicep/modules/blobcontainers:v2.0.0' = {
  name: 'ct-${deploymentTimeStamp}'
  params: {
    storageAccountName: storageAccountName
    containerNames: containerNames
  }

}
