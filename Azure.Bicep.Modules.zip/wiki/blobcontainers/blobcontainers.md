# Storage Account Blob Containers

[Data Factory Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/blobcontainers/blobcontainers-template.bicep&version=GBmain)


# Changelog

## V2.0.0
Initial module creation
