# Application Insights

[Application Insights Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/appinsights/appinsights-template.bicep&version=GBmain)


# Changelog

## V2.0.0
First App Insights module
