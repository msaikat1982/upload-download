// Creates an App Insight Component

@sys.description('Specifies a timestamp for module call.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

/////////////////////////
// Required Parameters //
/////////////////////////

@description('Azure region of the deployment')
param location string

@description('AppInsight name')
param appInsightName string

@description('Azure Resource Tags for the new resource.')
param tags object

/////////////////
// Module Call //
/////////////////

module appInsight '../../modules/appinsights/appinsights.bicep' = {
  name: 'appInsight-${deploymentTimeStamp}'
  params: {
    location: location
    appInsightName: appInsightName
    tags: tags
  }
}
