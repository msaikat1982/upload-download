//////////////////////
// REQUIRED PARAMETERS
//////////////////////

//The tenant ID where the Key Vault is deployed. This is provided for you.
param tenantId string = subscription().tenantId

//Specifies the Key Vault to add an Access Policy(s). Provide the name of the Key Vault.
param keyVaultName string = ''

//Specifies the Access Policy configuration. Supports Key Vault permissions for up to 16 identities. Refer to readme.md for full list of Key Vault permissions.
param accessPoliciesConfig array = [
  { 
  objectId: '' //Provide the Object ID of a user, service principal or security group in the Azure Active Directory tenant for the vault.
  tenantId: tenantId
  permissions: { //Provide a set of permissions for each access area...
    keys: [
     
    ]
    secrets: [
      
    ]
    certificates: [
      
    ]
  }
 }
]

//////////////
// CALL MODULE
//////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module accesspolicies 'br:gehabicep.azurecr.io/bicep/modules/keyvaultaccesspolicies:v2.0.0' = {
  name: 'ap-${deploymentTimeStamp}'
  params: {
    keyVaultName: keyVaultName
    accessPoliciesConfig: accessPoliciesConfig
  }
}
