//////////////////////
// REQUIRED PARAMETERS
//////////////////////

//The tenant ID where the Key Vault is deployed. This is provided for you.
param tenantId string = subscription().tenantId

//Specifies the Key Vault to add an Access Policy(s). Provide the name of the Key Vault.
param keyVaultName string = ''

//Specifies the environment specific policy set to apply...
param env string = 'dev'

//////////////
// CALL MODULE
//////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module mwaccesspolicies 'br:gehabicep.azurecr.io/bicep/modules/middlewarekeyvaultaccesspolicies:v2.0.0' = {
  name: 'ap-${deploymentTimeStamp}'
  params: {
    tenantId: tenantId
    keyVaultName: keyVaultName 
    env: env
  }
}
