# Middleware Key Vault Access Policies

Middleware Team has their own module for Key Vault access policies.
This helps to shorten the code required in their IaC project repositories.


[Middleware Key Vault Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/keyvaultaccesspolicies/middlewarekeyvaultaccesspolicies-template.bicep&version=GBmain)


# Changelog

## V2.0.0
Initial module creation