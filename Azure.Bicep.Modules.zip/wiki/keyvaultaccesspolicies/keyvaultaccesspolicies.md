# Key Vault Access Policies

Manage the Access Policies of Key Vault


[Key Vault Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/keyvaultaccesspolicies/keyvaultaccesspolicies-template.bicep&version=GBmain)



# Changelog

## V2.0.0
Initial Module creation