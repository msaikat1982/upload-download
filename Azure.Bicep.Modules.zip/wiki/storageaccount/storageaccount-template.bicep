/////////////////////////
// REQUIRED PARAMETERS //
/////////////////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
  
@description('Name the Azure storage account. Valid characters are lowercase letters and numbers. Max 24 characters')
param storageAccountName string = ''
  
@description('Specifies the Azure Region for the Storage Account. Allowed: centralus, eastus, northcentralus, southcentralus')
param location string = ''

@description('Specifies the Environment for Storage Account. Allowed: poc|dev|tst|stg|prd')
param env string = ''

@description('Specifies the full subnet Resource Id for deploying blob, file, queue, and table Private Endpoints. Use an empty string for no private endpoints.')
param subnetId string = ''

/////////////////////////
// OPTIONAL PARAMETERS //
/////////////////////////
  
@description('Enable hierarchical namespace on blob storage. Commonly enabled for Data Lake type storage.')
param hnsEnabled bool = true

@description('Specifies a name for each blob container you want to create. Provide comma separated values in single quotes.')
param containerNames array = []

@description('Specifies additional resource tags for the Storage Account. Provide Key: Value pairs')
param tags object = {}

@description('Used to put storage account access info into a key vault. Set values to true or false, name the keyvault, and add the params to your storage account module call.')
var storeAccessInfo = {
  storeAccessKey: true
  storeConnectionString: false
  keyvault: '' //name your keyvault here.
}

@description('Configure Diagnostics Settings to stream to Event Hub. Default is false.')
param streamDiagsToEventHub bool

////////////////////////////////
// STORAGE ACCOUNT DEPLOYMENT //
////////////////////////////////

module sa 'br:gehabicep.azurecr.io/bicep/modules/storageaccount:v3.1.5' = {
  name: 'sa-${deploymentTimeStamp}'
  scope: resourceGroup()
  params: {
    storageAccountName: storageAccountName
    location: location
    env: env
    subnetId: subnetId
    containerNames: containerNames
    storeAccessKey: storeAccessInfo.storeAccessKey
    keyvault: storeAccessInfo.keyvault
    hnsEnabled: hnsEnabled
    streamDiagsToEventHub: streamDiagsToEventHub
    tags: tags
  }
}
