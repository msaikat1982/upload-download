# Storage Account 

[Storage Account Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/storageaccount/storageaccount-template.bicep&version=GBmain)


# Changelog
## V3.1.8
Add westus event hub

## V3.1.7
Allow westus and Standard_LRS

## V3.1.6
Corrects a scope issue identified in v3.1.4. Non-breaking.

## V3.1.5
Fix: Corrects naming for storage account access keys added to a keyvault (consistent with AHEAD)

## V3.1.4
provides support for streaming diags to event hub.<br>
param: streamDiagsToEventHub<br>
type: bool<br>
default: false

## V3.1.3
provides support for enabling blob versioning.<br>
param: isBlobVersioningEnabled<br>
type: bool<br>
default: false

## V3.1.2
Fix: storageaccountsecret deployment name in storageaccount.bicep

## V3.1.1
With this version, you can use a set of params to store the storage account access key, connection string, or both, in an Azure Key Vault.<br>
Use this var and add the params (storeAccessKey, storeConnectionString, keyvault) to the storage account module call.

var storeAccessInfo = {<br>
&ensp;&ensp;storeAccessKey: true<br>
&ensp;&ensp;storeConnectionString: true<br>
&ensp;&ensp;keyvault: keyvault.outputs.keyvaultResourceName<br>
}<br><br>
BREAKING CHANGE: none

## V3.1.0
Added DFS private endpoint to list of private endpoints

## V3.0.0
Rename all private endpoints.
Fix duplicate private endpoint names
BREAKING CHANGE from V2
