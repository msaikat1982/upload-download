# Databricks

# Changelog

## V2.0.1

This version enabled Diagnostics on the Databricks workspace. Logs and metrics will be sent to a Log Analytics workspace.

## V2.0.0

This version calls another module (databricksnsg) that will create an NSG and assign the NSG to the public and private subnets of the databricks workspace.

## V1.0.0
Initial module creation
