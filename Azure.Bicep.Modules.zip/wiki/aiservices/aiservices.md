# AI Services

[AI Services Example Usage]()


# Changelog

## V1.0.5
Fix process for creating private endpoints and dns zones

## V1.0.4
Updates process for creating private endpoint and dns zones

## V1.0.2
Fixed Issue creating PE due to missing required property: customSubDomainName

## V1.0.1
Fixed Group IDs

## V1.0.0
First AI Services Module

