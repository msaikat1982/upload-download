////////////////////////////
//  Deployment Parameters //
////////////////////////////

@description('A timestamp for module calls')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

@description('Azure Region for ServiceBus Namespace')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string = 'centralus'

@description('Environment for ServiceBus Namespace')
@allowed(['poc','dev','tst','stg','prd'])
param env string = 'dev'

@description('Azure resource tags provided as key: value')
param tags object = {}

//////////////////////////
// ServiceBus Namespace //
//////////////////////////

@description('The name of the Service Bus namespace')
@minLength(6)
@maxLength(50)
param serviceBusNamespaceName string = 'serviceBus'

module servicebusnamespace 'br:gehabicep.azurecr.io/bicep/modules/servicebusnamespace:v3.0.0' = {
  name: 'sbns-${deploymentTimeStamp}'
  params: {
    serviceBusNamespaceName: serviceBusNamespaceName
    location: location
    env: env
    tags: tags
    subnetId: subnetId
  }
}

// ServiceBus Private Endpoint

@description('Specifies the full Resource Id of a Subnet for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = ''

///////////
// Queue //
///////////

@description('The name of the queue')
param queueName string = ''

@description('Max Delivery Count. Number of maximum deliveries, value ranging from 1 to 2000. Default is 10')
param maxDeliveryCount int = 10

@description('Max queue size in MB. Default is 1GB.')
param queue_maxSizeInMegabytes int = 1024

module queue 'br:gehabicep.azurecr.io/bicep/modules/servicebusqueue:v3.0.0' = {
  name: 'queue-${deploymentTimeStamp}'
  params: {
    serviceBusNamespace: servicebusnamespace.outputs.serviceBusNamespaceName
    queueName: queueName
    maxDeliveryCount: maxDeliveryCount
    maxSizeInMegabytes: queue_maxSizeInMegabytes
  }
}

///////////
// Topic //
///////////

@description('The name of the topic')
param topicName string = ''

@description('Maximum size (in KB) of the message payload that can be accepted by the topic.')
param maxMessageSizeInKilobytes int =  1024

@description('Maximum size of the topic in megabytes, which is the size of the memory allocated for the topic.')
param topic_maxSizeInMegabytes int = 1024

module topic 'br:gehabicep.azurecr.io/bicep/modules/servicebusnamespacetopic:v3.0.0' = {
  name: 'topic-${deploymentTimeStamp}'
  params: {
    serviceBusNamespace: servicebusnamespace.outputs.serviceBusNamespaceName
    topicName: topicName
    maxMessageSizeInKilobytes: maxMessageSizeInKilobytes
    maxSizeInMegabytes: topic_maxSizeInMegabytes
  }
}

//////////////////
// Subscription //
//////////////////

@description('The name of the subscription')
param subscriptionName string = ''

module subscription 'br:gehabicep.azurecr.io/bicep/modules/servicebusnamespacetopicsubscription:v3.0.0' = {
  name: 'subscription-${deploymentTimeStamp}'
  params: {
    serviceBusNamespace: servicebusnamespace.outputs.serviceBusNamespaceName
    topicName: topic.outputs.topicName
    subscriptionName: subscriptionName
  }
}

///////////
// Rules //
///////////

@description('The name of the rule')
param ruleName string = ''

@description('Sql Expression')
param sql_sqlExpression string = ''

module rule 'br:gehabicep.azurecr.io/bicep/modules/servicebusnamespacetopicsubscriptionrule:v3.0.0' = {
  name: 'rule-${deploymentTimeStamp}'
  params: {
    serviceBusNamespace: servicebusnamespace.outputs.serviceBusNamespaceName
    topicName: topic.outputs.topicName
    subscriptionName: subscription.outputs.subscriptionName
    ruleName: ruleName
    sql_sqlExpression: sql_sqlExpression
  }
}
