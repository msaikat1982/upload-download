# Service Bus Namespace

[Machine Learning Workspace Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/servicebusnamespace/servicebusnamespace-template.bicep&version=GBmain)


# Changelog
## V3.0.2
use fully qualified id for event hub namespace

## V3.0.1
Configures diagnostics settings to send all logs and all metrics to Event Hub

## V3.0.0
integrate private endpoint
Disable public network access
Output APIVersion
