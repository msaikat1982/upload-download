# Synapse Workspace

[Synapse Workspace Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/templates/synapse/synapseworkspace-template.bicep&version=GBmain)

This module deploys the Synapse workspace, Azure integration runtime in a managed private network, private endpoints on your VNET.
It requires a storage account to deploy this module.
You can optionally spin up a dedicated SQL pool with this module in your workspace.

**Note: Managed Private Endpoints**:

This module will deploy three managed private endpoints for you:
1. Synapse Dedicated SQL Pool
2. Synapse SQL On-demand
3. DFS to the Storage Account used by SQL On-demand

Any other managed private endpoint you may need must be deployed manually. 

**Note: MPEs committed to a branch will not deploy**:
In our YAML Azure Pipelines files, deploying managed private endpoints is set to false:

'DeployManagedPrivateEndpoints: false'

This means that if an MPE is merged into master branch from a feature branch, it will still not be deployed in the pipeline.


# Changelog

## V3.0.6
sets Entra Admin group to SQLAdmins security group

## V3.0.5
adds support for deploying managed vNet IR and parameterize storageAcctType. Default is GRS.

## V3.0.4
adds support for deploying dedicated SQL pools

## V3.0.3
Initial creation of module