//////////////////////////////////
// SYNAPSE WORKSPACE DEPLOYMENT //
//////////////////////////////////

@description('The name of the Synapse instance to be deployed.')
param synapseWorkspaceName string = 'platformtestwp1'

// Specifies the Azure Region for the deployment. Allowed: 'centralus','eastus','northcentralus','southcentralus'
param location string = 'eastus'

// Specifies additional resource tags for the resource. Provide key/value pairs, like, Description: 'A new Synapse' 
param tags object = {
    
}

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

@description('Specifies the full subnet Resource Id for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = ''

// Your Synapse Workspace will require references to an ADLS storage account with at least the 'synapseroot' Container object //
// Reference an existing storage account or the output from a storage account module call in your deployment file...
// resource adlsaccount 'Microsoft.Storage/storageAccounts@2023-05-01' existing = {
//   name: 'adlsstorageaccount'
// }
// param sqlAdministratorLogin string = 'sqladmin'
// @secure()
// param sqlAdministratorLoginPassword string

module st 'br:gehabicep.azurecr.io/bicep/modules/storageaccount:v3.1.0' = {
  name: 'st-${deploymentTimeStamp}'
  params: {
    storageAccountName: 'platformtststgactwp01'
    location: location
    env: 'dev'
    tags: tags
    // containerNames: containerNames
    subnetId: subnetId
    hnsEnabled: true
  }
}



@description('Synapse workspace Git configuration')
param workspaceRepositoryConfiguration object = {
  // accountName: ''
  // collaborationBranch: ''
  // hostName: ''
  // lastCommitId: ''
  // projectName: ''
  // repositoryName: ''
  // rootFolder: ''
  // tenantId: ''
  // type: ''
}

@description('Object used to create dedicated SQL pools.')
var dedicatedSqlPools = {
  // sqlPool1: {
  //   name: 'synapseSQL'
  //   sku: 'DW1000c'
  // }
  // sqlPool2: {
  //   name: 'synapseSQL2'
  //   sku: 'DW100c'
  // } 
}

//////////////////////
// PRIVATE ENDPOINT //
//////////////////////

/*

  To create a Private Endpoint for your Synapse instance, pass the full Subnet ID of your subnet from the Azure Portal.

  Example:
  param subnetId string = '/subscriptions/<subscriptionId>/resourceGroups/<resource-group>/providers/Microsoft.Network/virtualNetworks/<vnet-name>/subnets/<subnet-name>'

  Leave 'subnetId' empty (pass an empty string) to NOT create a Private Endpoint

*/


module synapseworkspace 'br:gehabicep.azurecr.io/bicep/modules/synapseworkspace:v3.0.5' = {
  name: 'synapse-${deploymentTimeStamp}'
  dependsOn: [
    st
  ]
  params: {
    subnetId: subnetId
    //purviewId: purviewId
    workspaceRepositoryConfiguration: workspaceRepositoryConfiguration
    location: location
    tags: tags
    synapseWorkspaceName: synapseWorkspaceName
    workspaceDataLakeAccountName: st.name // name from your storage account reference
    defaultDataLakeStorageResourceId: st.outputs.storageAccountResourceId // id from your storage account reference
    dedicatedSqlPools: dedicatedSqlPools
  }
}
