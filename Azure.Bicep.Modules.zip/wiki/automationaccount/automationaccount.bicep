param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

param accountName string
param location string
param subnetId string
param tags object

module automationaccount '../../modules/automationaccount/automationaccount.bicep' = {
  name: 'aa-${deploymentTimeStamp}'
  params: {
    accountName: accountName
    location: location
    subnetId: subnetId
    tags: tags
  }
}
