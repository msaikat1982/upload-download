using './automationaccount.bicep'

param accountName = ''
param location = ''
param subnetId = ''
param tags = {}
