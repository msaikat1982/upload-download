# Azure SQL

# Changelog

## V2.0.0
Upgraded SqlServer resource call to lateset API version
The schema for the resource has changed.

## V1.0.1
Parameter added to disable public access

## V1.0.0
Initial module creation