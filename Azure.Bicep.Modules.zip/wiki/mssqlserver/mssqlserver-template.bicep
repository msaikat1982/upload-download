targetScope = 'subscription'

///////////////////////////
// DEPLOYMENT PARAMETERS //
///////////////////////////

@description('The subnet Id for Private Endpoints in this deployment.')
param subnetId string

@description('The Azure Region for this deployment.')
param location string

// Azure Resource tags (applies to all resources in this deployment)
@description('Azure Resource Tags for the new resources.')
param tags object

@description('A timestamp for naming unique deployments.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

@secure()
param adminPassword string

///////////////////////////////
// RESOURCE GROUP DEPLOYMENT //
///////////////////////////////

@description('The name of the Resource Group where new resources will be deployed.')
param rgName string

@description('The Resource Group where new resources will be deployed.')
resource dbaSqlRg 'Microsoft.Resources/resourceGroups@2022-09-01' = {
  name: rgName
  location: location
  tags: tags
}

///////////////////////////
// SQL Server Deployment //
///////////////////////////


@description('Details of the SQL Server required by the Environment.')
param sqlServerDetails object

module sqlServer 'br:gehabicep.azurecr.io/bicep/modules/mssqlserver:v2.0.0' = {
  name: 'sqlServer-${deploymentTimeStamp}'
  scope: resourceGroup(dbaSqlRg.name)
  params: {
    name: sqlServerDetails.name
    location: sqlServerDetails.location
    adminLogin: sqlServerDetails.adminLogin
    adminPassword: adminPassword
    tags: tags
    subnetId: subnetId
  }
}
