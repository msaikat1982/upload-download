using 'mssqlserver-template.bicep'

///////////////////////////
// DEPLOYMENT PARAMETERS //
///////////////////////////

// Resource Group

@description('The Resource Group where new resources will be deployed.')
param rgName = 'rg-team-sql-dev-01'

param location = 'eastus'

@description('Azure Resource Tags for the new resources.')
param tags = {
  Owner: 'yourTeam'
  Environment: 'dev'
}

// SQL Server

@description('The details of the SQL Server.')
param sqlServerDetails = {
  name: 'sql-team-project-dev-eus-01'
  location: location
  adminLogin: 'yourAdminUsername'
}

// Seprate from above object since it can't be nested when passed to CLI in pipeline.
param adminPassword = '' //Passed in pipeline parameter from ADO library group

param subnetId = '/subscriptions/xxxxxxxxx/resourceGroups/rg-alz-xxxxxxx/providers/Microsoft.Network/virtualNetworks/vnet-xxxxxx/subnets/snet-xxxxx'

