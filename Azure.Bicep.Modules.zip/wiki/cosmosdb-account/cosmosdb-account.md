# CosmosDB Account

# Changelog

## V1.0.1
Integrate event hub streaming.
Backup policy updated from 'Periodic' to 'Continuous'

## V1.0.0
Initial module creation