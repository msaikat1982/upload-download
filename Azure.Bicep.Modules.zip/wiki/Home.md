# Azure Bicep Modules

Welcome to the Azure Bicep Modules Wiki.
These markdown files are managed in the Azure.Bicep.Modules git repository. 

This wiki is meant to display all available bicep modules that are hosted by the GEHA Cloud and Platform Services Team.
Within each folder you will find a markdown file with a link to example usage of a module, as well as a changelog.
 
It is recommended to always use the latest version available of a module.

For more information, please see https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/README.md&_a=preview