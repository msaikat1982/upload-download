//Creates an App Service in Azure
//Azure App Service is an HTTP-based service for hosting web applications, REST APIs, and mobile back ends.
//For information on App Servce refer to: https://learn.microsoft.com/en-us/azure/app-service/overview

/////////////////////////
// Required Parameters //
/////////////////////////

@description('Name of the associated App Service.')
param name string

@description('Specifies the Azure Region for the App Service. Allowed: centralus|eastus|northcentralus|southcentralus')
param location string

@description('Name of the associated App Service plan.')
param aspName string

@description('Name of the App Insights instance to connect to.')
param appInsightsName string

@description('Azure Resource Manager ID of the Virtual network and subnet to be joined by Regional VNET Integration.')
param vNetSubnetId string

param subnetId string

@description('The type of service and its capabilities.')
var kind = {
	WindowsWebapp: 'app'
	LinuxWebapp: 'app,linux'
	LinuxContainerWebapp: 'app,linux,container'
	WindowsContainerWebAppHyperV: 'hyperV'
	WindowsContainerWebApp: 'app,container,windows'
	LinuxWebApponARC: 'app,linux,kubernetes'
	LinuxContainerWebApponARC: 'app,linux,container,kubernetes'
	FunctionCodeApp: 'functionapp'
	LinuxConsumptionFunctionapp: 'functionapp,linux'
	FunctionContainerApponARC: 'functionapp,linux,container,kubernetes'
	FunctionCodeApponARC: 'functionapp,linux,kubernetes'
}

/////////////////////////
// Optional Parameters //
/////////////////////////

//Specifies additional tags like Owner=Group requesting App Service 
param tags object = {}

/////////////////
// CALL MODULE //
/////////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module appService 'br:gehabicep.azurecr.io/bicep/modules/appservice:v1.0.4' = {
  name: 'appservice-${deploymentTimeStamp}'
  params: {
	  name: name
	  location: location
	  tags: tags
	  kind: kind.LinuxWebapp
		appInsightsName: appInsightsName
	  aspName: aspName
	  subnetId: subnetId
	  vNetSubnetId: vNetSubnetId
	}
}
