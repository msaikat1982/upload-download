# App Service

#[App Service Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/appservice/appservice-template.bicep&version=GBmain)

# Changelog

# V1.0.5
Confgures Diagnostic Settings to stream to Event Hub

# V1.0.4
Updates process for creating private endpoint and dns zones

## V1.0.3
Initial App Service Module
