# CosmosDB SQLDB Container

# Changelog

## V1.0.0
Initial module creation


