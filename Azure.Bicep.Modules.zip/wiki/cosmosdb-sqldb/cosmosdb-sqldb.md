# CosmosDB SQLDB

# Changelog

## V1.0.2
Fixed issue with parsing either 'autoScaling' our 'throughput' values, but always either one or the other.

## V1.0.0
Initial module creation


