//account

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

param env string= 'dev'

@description('Azure Region to deploy Cosmos SQL DB to')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string = 'eastus'

param subnetId string = ''

param cosmosDetails object = {
  name: 'csms-acct-${env}-01'
  kind: 'GlobalDocumentDB'
  identityType: 'SystemAssigned'
  tags: {
    ResourceType: 'Cosmos SQL DB'
  }
  dbName: 'csms-sqldb-${env}-01'
  dbThroughput: 100
  dbMaxThroughput: 1000
  containers: [
    {
      cntName: 'csms-sqlcnt'
      cntPartKeyPaths: [
        '/user_id'
      ]
      sharedThroughput: true
      throughput: null
      maxThroughput: null     
    }
    {
      cntName: 'chat-history'
      cntPartKeyPaths: [
        '/user_id'       
      ]
      sharedThroughput: true
      throughput: null
      maxThroughput: null
    }
  ]
}

module csmsaccount 'br:gehabicep.azurecr.io/bicep/modules/cosmosdbaccount:v1.0.1' = {
  name: 'accnt-${deploymentTimeStamp}'
  params: {
    location: location
    name: cosmosDetails.name
    subnetId: subnetId
    tags: {}
  }
}


module db 'br:gehabicep.azurecr.io/bicep/modules/cosmosdbsqldb:v1.0.2' = {
  name: 'csmsdb-${deploymentTimeStamp}'
  params: {
    cosmosAccountName: csmsaccount.outputs.cosmosResourceName
    location: location
    name: cosmosDetails.dbName
  }
}
