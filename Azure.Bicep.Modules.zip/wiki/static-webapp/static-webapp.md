# Static Web App

# Changelog

## V1.0.0
Initial module creation