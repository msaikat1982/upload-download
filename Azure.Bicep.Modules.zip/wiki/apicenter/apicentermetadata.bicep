@description('A timestamp for naming unique deployments.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

param apiCenterName string
param metadataDetails array

module apimetadata '../../modules/apicenter/apicentermetadata.bicep' = {
  name: 'metadata-${deploymentTimeStamp}'
  params: {
    apiCenterName: apiCenterName
    metadataDetails: metadataDetails
  }
}
