using './apicenterdeployment.bicep'

@description('Details of the API.')
param apiDetails = {
  apiCenterName: 'apicenter-name'
  apiName: 'api-name'
  apiVersion: 'v1'
  apiType: 'apiType'
  apiSummary: 'This is a summary of the API.'
  apiDescription: 'This is a description of the API.'
  externalDocs: [
    {
      externalDocTitle: 'External Documentation Title'
      externalDocDescription: 'External Documentation Description'
      externalDocUrl: 'https://example.com/docs'
    }
    {
      externalDocTitle: 'External Documentation Title 2'
      externalDocDescription: 'External Documentation Description 2'
      externalDocUrl: 'https://example2.com/docs'
    }
  ]
  contactName: 'Contact Name'
  contactEmail: 'contact@example.com'
  contactUrl: 'https://example.com/contact'
  customPublicFacing: true
  customLineOfBusiness: []
  customTier1Support: true
  lifecycleStage: 'Testing'
  apiDefinitionTitle: 'API Definition Title'
  deployments: [
    {
      deploymentDescription: 'Deployment Description'
      deploymentEnvironmentId: '/workspaces/default/environments/aks-dev'
      deploymentRuntimeUris: ['https://runtime.example.com']
      deploymentState: 'Active'
    }
    {
      deploymentDescription: 'Deployment Description 2'
      deploymentEnvironmentId: '/workspaces/default/environments/aks-test'
      deploymentRuntimeUris: ['https://runtime.example.com']
      deploymentState: 'Active'
    }
  ]
}
