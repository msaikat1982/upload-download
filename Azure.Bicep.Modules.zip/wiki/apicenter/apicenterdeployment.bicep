@description('A timestamp for naming unique deployments.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

param apiDetails object

module api 'br:gehabicep.azurecr.io/bicep/modules/apicenter:v2.0.9' = {
  name: 'api-${deploymentTimeStamp}'
  params: {
    apiDetails: apiDetails
  }
}
