# API Center 

# Changelog

## V2.0.10:

V2.0.10 adds 'Dental' to list of allowed 'Line of Business' options

## V2.0.9:

V2.0.9 provides for multiple externals docs and multiple deployments per api. also ensures api names are lower case

## V2.0.8:

V2.0.8 removes 'definitionName' and 'deploymentTitle' from required params and formats them based on other values

## V2.0.6:

V2.0.6 reverts the definitionId for 'Microsoft.ApiCenter/services/workspaces/apis/deployments@2024-06-01-preview'

## V2.0.5:

V2.0.5 adds an array for type object Line Of Business custom properties

## V2.0.4:

V2.0.4 corrects the definitionId for 'Microsoft.ApiCenter/services/workspaces/apis/deployments@2024-06-01-preview'

## V2.0.3:

V2.0.3 adds a type object for Line Of Business custom properties

## V2.0.2:

V2.0.2 updates the definition apiCenterDeployment 'definitionID' parameter value

## V2.0.1:

V2.0.1 adds deployment outputs to the apicenter module.

## V2.0.0: BREAKING

V2.0.0 moves the apiDetails object to the module. You now pass only the 'apiDetails' object in your module call. This should shorten lines of code in your deployment file.

## V1.0.0
Initial module. 
