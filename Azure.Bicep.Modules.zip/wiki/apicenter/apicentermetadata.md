# API Center 

# Changelog

## V1.0.1:

adds 'Dental' to list of allowed 'Line of Business' options

## V1.0.0:

Publish initial metadata module