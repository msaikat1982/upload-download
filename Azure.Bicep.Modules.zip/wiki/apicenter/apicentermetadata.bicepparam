using 'apicentermetadata.bicep'

param apiCenterName = 'apim-apim-nonprd-centralus-01-APIC'

var lineofbusines_Schema = '''{
      "type":"array",
      "title":"Line of Business",
      "description":"Property to indicate the business unit that uses the API",
      "items":{
      "type":"string",
      "oneOf":[
      {"const":"IT","description":"APIs used for internal IT processes"},
      {"const":"Marketing","description":"APIs that interface with marketing platforms including Salesforce"},
      {"const":"Member","description":"APIs that enable interaction with Member data"},
      {"const":"Provider","description":"APIs that enable interaction with Provider data"},
      {"const":"Claims","description":"APIs that enable interaction with Claims data"},
      {"const":"Dental","description":"APIs that enable interaction with Dental data"}
      ]}}'''

var publicfacing_Schema = '''{
      "type":"boolean",
      "title":"Public Facing",
      "description":"Indicates whether an API is accessible via the internet"
      }'''

var tier1support_Schema = '''{
      "type":"boolean",
      "title":"Tier 1 Support"
      }'''

@description('Details of the Metadata.')
param metadataDetails = [
  {
    name: 'lineofbusiness'
    properties: {
      assignedTo: [
        {
          entity: 'api'
          required: true
          deprecated: false
        }
        {
          entity: 'deployment'
          required: false
          deprecated: false
        }
        {
          entity: 'environment'
          required: false
          deprecated: false
        }
      ]
      schema: lineofbusines_Schema
    }
  }
  {
    name: 'publicfacing'
    properties: {
      assignedTo: [
        {
          entity: 'api'
          required: true
          deprecated: false
        }
      ]
      schema: publicfacing_Schema
    }
  }
  {
    name: 'tier1support'
    properties: {
      assignedTo: [
        {
          entity: 'api'
          required: true
          deprecated: false
        }
      ]
      schema: tier1support_Schema
    }
  }
]
