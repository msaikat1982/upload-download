# Azure SQL Database

## SKUs available
To check what SKUs are available for Azure SQL, run the following AZ CLI command:
```bash
az sql db list-editions --location eastus --output table
```

# Changelog

## V2.0.0
Upgraded API version of resource call. 
Schema for resource has changed.

## V1.0.0
Initial module creation