# Private Endpoint

# Changelog

## V2.0.2
Fixed multiple zones in single PVe

## V2.0.1
Added ability to add multiple DNS zones to a single PVE

## V2.0.0
Initial module creation