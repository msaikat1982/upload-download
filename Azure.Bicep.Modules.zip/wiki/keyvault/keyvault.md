# Key Vault

[Key Vault Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/keyvault/keyvault-template.bicep&version=GBmain)

[Key Vault RBAC Role IDs](https://learn.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli#azure-built-in-roles-for-key-vault-data-plane-operations)

# Changelog

## V4.0.2
Removes call to external module 'keyvaultrbac' and integrates all role assigment into this module

## V4.0.1
Interate keyvault RBAC assignment calls to keyvault module

## V4.0.0
Update to use RBAC instead of access policies for keyvault.

## V3.0.0
Adds private endpoints to module if subnet ID specified
BREAKING CHANGE if you manage the private endpoint elsewhere. 

## V2.0.5
Adjusts default access policy to add Platform and Security Team access
