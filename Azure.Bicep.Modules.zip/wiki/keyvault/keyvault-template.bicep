/////////////////////////
// REQUIRED PARAMETERS //
/////////////////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

// Name the Azure Key Vault. Max 24 characters.
param keyVaultName string = ''

// Specifies the Azure Region for the Key Vault. Allowed: 'centralus','eastus','northcentralus','southcentralus'
param location string = ''

// Specifies the Environment for Key Vault. Allowed: poc|dev|tst|stg|prd
param env string = ''

// Deploys a private endpoint in this subnet
@description('Specifies the full subnet Resource Id for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = ''

/////////////////////////
// OPTIONAL PARAMETERS //
/////////////////////////

// Using 'true' will define an Access Policy for environment specific AKS Key Vault provider
param isAKSintegrated bool = false

// Specifies additional resource tags for the Key Vault. Provide key/value pairs, like, Description: 'A new Key Vault' 
param tags object = {
    
}

// if you have no additional RBAC to assign, you can pass an empty array...
@description('An array of additional RBAC role assigments')
param rbac array = [
  // {
  //   roleName: 'Key Vault Secrets User'
  //   roleId: '4633458b-17de-408a-b874-0445c86b69e6'
  //   principals: [
  //     'Object ID' // Label the principal
  //   ]
  // }
]

/////////////////////////
// KEYVAULT DEPLOYMENT //
/////////////////////////

module keyvault 'br:gehabicep.azurecr.io/bicep/modules/keyvault:v4.0.2' = {
  name: 'kv-${deploymentTimeStamp}'
  params: {
    keyVaultName: keyVaultName
    location: location
    env: env
    subnetId: subnetId
  }
}
