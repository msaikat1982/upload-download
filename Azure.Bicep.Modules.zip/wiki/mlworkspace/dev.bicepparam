using './mlworkspace-template.bicep'

// Resource Group //
@description('The Resource Group where new resources will be deployed.')
param rgName = 'rg-da-ml-dev'

param location = 'eastus'
param env = 'dev'
param tags = {
  Description: 'A Machine Learning Workspace for Data Analytics in the Dev environment.'
  Environment: 'Develop'
  Owner: 'Data Analytics'
}
param mldescription = 'A Machine Learning Workspace for Data Analytics in the Dev environment.'
param keyVaultName = 'kv-da-ml-dev'
param storageAccountName = 'mlstdev${uniqueString(rgName)}'
param containerNames = []
param containerRegistryName = 'dataanalyticsmachinelearningdev'
param appInsightName = 'appi-da-ml-dev'
param mlworkspaceName = 'DA-ML-DEV'
param deploySharedStorageAccount = true

// AML Private Endpoint Parameters...

// The full Resource ID of your vnet. 
var vnetId = '/subscriptions/c0097ced-d96e-4419-a7f4-74d3234387c5/resourceGroups/rg-alz-eastus-vnet-da-ml-eus-dev-01/providers/Microsoft.Network/virtualNetworks/vnet-da-ml-eus-dev-01'

// The name of your subnet...
var subnet = 'snet-da-ml-dev-01'

// Interpolate for subnetId. Do not modify...
param subnetId = '${vnetId}/subnets/${subnet}'
