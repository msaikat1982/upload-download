targetScope = 'subscription'

///////////////////////////
// DEPLOYMENT PARAMETERS //
///////////////////////////

@sys.description('Specifies a timestamp for module call.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

@sys.description('Specifies the Azure Region for the ML Workspace resources.') 
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@sys.description('Specifies the Environment for ML Workspace.')
@allowed(['poc','dev','tst','stg','prd'])
param env string

// Azure Resource tags (applies to all resources in this deployment)
@sys.description('Azure Resource Tags for the new resources.')
param tags object

@sys.description('Id of the subnet for Private Endpoints in this subscription.')
param subnetId string

/////////////////////////
// RESOURCE PARAMETERS //
/////////////////////////

// Resource Group //
@sys.description('The Resource Group where new resources will be deployed.')
param rgName string

// Create a Resource Group.
resource amlRg 'Microsoft.Resources/resourceGroups@2022-09-01' = {
  name: rgName
  location: location
  tags: tags
}

/////////////////////////
// KEYVAULT PARAMETERS //
/////////////////////////

@sys.description('Name the Azure Key Vault. Max 17 characters.')
param keyVaultName string

module keyvault 'br:gehabicep.azurecr.io/bicep/modules/keyvault:v2.0.5' = {
  name: 'kv-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    keyVaultName: keyVaultName
    location: location
    env: env
    tags: tags
  }
}

////////////////////////////////
// STORAGE ACCOUNT PARAMETERS //
////////////////////////////////
  
@sys.description('Name the Azure storage account. Valid characters are lowercase letters and numbers. Max 24 characters')
param storageAccountName string

@sys.description('Specifies a name for each blob container you want to create. Provide container names in quotes, like \'container1\',\'container2\'')
param containerNames array

@sys.description('Deploy shared storage account (Dev Only)')
param deploySharedStorageAccount bool

module storageaccount 'br:gehabicep.azurecr.io/bicep/modules/storageaccount:v2.0.5' = {
  name: 'st-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    storageAccountName: storageAccountName
    location: location
    env: env
    tags: tags
    containerNames: containerNames
  }
}

module sharedstorageaccount 'br:gehabicep.azurecr.io/bicep/modules/storageaccount:v2.0.5' = if (deploySharedStorageAccount) {
  name: 'sharedst-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    storageAccountName: 'stdatascishared'
    location: location
    env: env
    tags: tags
    containerNames: containerNames
  }
}

///////////////////////////////////
// CONTAINER REGISTRY PARAMETERS //
///////////////////////////////////

@sys.description('Container registry name')
param containerRegistryName string

module containerRegistry '../../modules/containerregistry/containerregistry.bicep' = {
  name: 'acr-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    location: location
    containerRegistryName: containerRegistryName
    tags: tags   
  }
}

/////////////////////////////
// APP INSIGHTS PARAMETERS //
/////////////////////////////

@sys.description('AppInsight name')
param appInsightName string

module appInsight '../../modules/appinsights/appinsights.bicep' = {
  name: 'appInsight-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    location: location
    appInsightName: appInsightName
    tags: tags
  }
}

/////////////////////////////
// ML WORKSPACE PARAMETERS //
/////////////////////////////

@sys.description('The ML Workspace name')
param mlworkspaceName string

@sys.description('The description of this workspace.')
param mldescription string

@sys.description('var for outbound ruleset in AML Workspace. Creates managed private endpoint')
var varAmlOutboundRules = [
  {
    resourceName: sharedstorageaccount.name
    resourceId: sharedstorageaccount.outputs.storageAccountResourceId
    resourceTargetType: 'blob'
  }
]

module mlworkspace '../../modules/mlworkspace/mlworkspace.bicep' = {
  name: 'mlworkspace-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  dependsOn: [appInsight,containerRegistry,keyvault,storageaccount]
  params: {
    location: location
    mlworkspaceName: mlworkspaceName
    description: mldescription
    applicationInsightsId: appInsight.outputs.appInsightId
    containerRegistryId: containerRegistry.outputs.containerRegistryId
    keyVaultId: keyvault.outputs.keyvaultResourceId
    storageAccountId: storageaccount.outputs.storageAccountResourceId
    tags: tags
  }
}

// OUTBOUND RULES

module outboundruleBlob '../../modules/mlworkspace/amloutboundrule.bicep'  = {
  name: 'aml-outboundBlob-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  dependsOn: [mlworkspace,sharedstorageaccount]
  params:{
    mlworkspaceName: mlworkspace.outputs.mlworkspaceName
    serviceResourceName: sharedstorageaccount.outputs.storageAccountResourceName
    serviceResourceId: sharedstorageaccount.outputs.storageAccountResourceId
    resourceTargetType: 'blob'
  }
}

module outboundruleFile '../../modules/mlworkspace/amloutboundrule.bicep' = {
  name: 'aml-outboundFile-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  dependsOn: [mlworkspace,sharedstorageaccount,outboundruleBlob]
  params:{
    mlworkspaceName: mlworkspace.outputs.mlworkspaceName
    serviceResourceName: sharedstorageaccount.outputs.storageAccountResourceName
    serviceResourceId: sharedstorageaccount.outputs.storageAccountResourceId
    resourceTargetType: 'file'
  }
}

///////////////////////
// Private Endpoints //
///////////////////////

@sys.description('Object used to select the groupId and Private DNS Zone. Required by the Private Endpoint module.')
var dnsZoneConfig = {
  blob: {
    groupId: 'Blob'
    privateDnsZone: 'privatelink.blob.core.windows.net'
  }
  file: {
    groupId: 'File'
    privateDnsZone: 'privatelink.file.core.windows.net'
  }
  keyvault: {
    groupId: 'vault'
    privateDnsZone: 'privatelink.vaultcore.azure.net'
  }
  dataFactory: {
    groupId: 'dataFactory'
    privateDnsZone: 'privatelink.datafactory.azure.net'
  }
  mlworkspace: {
    groupId: 'amlworkspace'
    privateDnsZone: 'privatelink.api.azureml.ms'
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for Machine Learning Workspace...
module amlPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [mlworkspace]
  name: 'amlPvtEp-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: mlworkspace.outputs.mlworkspaceId
    pvtEpName: '${mlworkspace.outputs.mlworkspaceName}-pvtep'
    location: location
    groupdId: dnsZoneConfig.mlworkspace.groupId
    privateDnsZone: dnsZoneConfig.mlworkspace.privateDnsZone
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for Keyvault...
module kvPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [keyvault]
  name: 'kvPvtEp-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: keyvault.outputs.keyvaultResourceId
    pvtEpName: '${keyvault.outputs.keyvaultResourceName}-pvtep'
    location: location
    groupdId: dnsZoneConfig.keyvault.groupId
    privateDnsZone: dnsZoneConfig.keyvault.privateDnsZone
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for Blob storage...
module stPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [storageaccount]
  name: 'stPvtEp-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: storageaccount.outputs.storageAccountResourceId
    pvtEpName: '${storageaccount.outputs.storageAccountResourceName}-pvtep'
    location: location
    groupdId: dnsZoneConfig.blob.groupId
    privateDnsZone: dnsZoneConfig.blob.privateDnsZone
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for File storage...
module stPvtEpFile 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [storageaccount]
  name: 'stPvtEpFile-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: storageaccount.outputs.storageAccountResourceId
    pvtEpName: '${storageaccount.outputs.storageAccountResourceName}-file-pvtep'
    location: location
    groupdId: dnsZoneConfig.file.groupId
    privateDnsZone: dnsZoneConfig.file.privateDnsZone
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for Shared Blob storage...
module sharedStPvtEp 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [sharedstorageaccount]
  name: 'sharedStPvtEp-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: sharedstorageaccount.outputs.storageAccountResourceId
    pvtEpName: '${sharedstorageaccount.outputs.storageAccountResourceName}-pvtep'
    location: location
    groupdId: dnsZoneConfig.blob.groupId
    privateDnsZone: dnsZoneConfig.blob.privateDnsZone
  }
}

// Module call to create Private Endpoint and Private Endpoint DNS for Shared File storage...
module sharedStPvtEpFile 'br:gehabicep.azurecr.io/bicep/modules/privateendpoint:v2.0.0' = {
  dependsOn: [sharedstorageaccount]
  name: 'sharedStPvtEpFile-${deploymentTimeStamp}'
  scope: resourceGroup(amlRg.name)
  params: {
    subnetId: subnetId
    resourceId: sharedstorageaccount.outputs.storageAccountResourceId
    pvtEpName: '${sharedstorageaccount.outputs.storageAccountResourceName}-file-pvtep'
    location: location
    groupdId: dnsZoneConfig.file.groupId
    privateDnsZone: dnsZoneConfig.file.privateDnsZone
  }
}
