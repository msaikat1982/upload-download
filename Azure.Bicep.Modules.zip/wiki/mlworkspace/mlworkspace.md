# Machine Learning Workspace

[Machine Learning Workspace Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/mlworkspace/mlworkspace-template.bicep&version=GBmain)



# Changelog

## V3.0.4
Update to use 1 private endpoint with multiple DNS zones

## V3.0.3
account for duplicate pvtep naming with an additional dnsZoneConfig item

## V3.0.2
account for duplicate pvtep group IDs
