# Machine Learning Workspace Outbound Rule

# Changelog

## V2.0.0
Initial module creation