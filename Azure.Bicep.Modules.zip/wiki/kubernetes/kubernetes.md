# Azure Kubernetes Service

## Setup
When deploying a Private AKS cluster, there are a few things needed during your setup to allow the deployment to be successful:
1. Azure Firewall - A policy/rule needs added to allow traffic outbound for the node pool. This allows traffic to reach your
DNS servers, but also allows the Ubuntu servers to reach the internet to grab any system dependencies they need.
2. When using on-premise DNS for the node pool (The VNET your nodepool uses sets this), make sure a conditional forwarder
exists that sends the request to our Private DNS Resolvers in Azure.
3. In the Private DNS Zone in Azure, an A recored will manually need added for the privatelink address that points to the k8s API.
This allows the node pool to resolve and reach the k8s API.

# Changelog
