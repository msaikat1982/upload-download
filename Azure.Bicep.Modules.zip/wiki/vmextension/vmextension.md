# VM Extension

# Changelog

## V1.0.1
Fix typeHandlerVersion expression in module

## V1.0.0
Initial module
