/* https://learn.microsoft.com/en-us/azure/templates/microsoft.compute/virtualmachines/extensions?pivots=deployment-language-bicep

This module should have an imlicit dependency on a VM deployment.

Deploy your VM with virtualmachine.bicep and reference its name in the vmExtension module call...

module virtualMachine '../modules/virtualmachine.bicep' = {
  name: 'vm-${deploymentTimeStamp}'
  scope: resourceGroup(teRg.name)
  params: {
    location: location
    vmDetails: vmDetails
    adminPassword: adminPassword
  }
}

*/

@description('The name of your VM Extension')
param extName string = ''

@description('The script to run on your VM.')
var teInstallScript = '''
#!/bin/bash

  # your script here...

'''

module vmExtension 'br:gehabicep.azurecr.io/bicep/modules/vmextension:v1.0.0' = {
  name: 'ext-${deploymentTimeStamp}'
  scope: resourceGroup(Rg.name)
  params: {
    location: location
    vmName: virtualMachine.outputs.virtualMachineName
    extName: extName
    commandToExecute: teInstallScript
  }
}
