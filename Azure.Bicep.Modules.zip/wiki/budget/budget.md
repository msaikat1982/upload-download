# Budget

[Budget Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/budget/budget-template.bicep&version=GBmain)

# Changelog
## V2.0.1
Adds a default endDate if not provided in a module call.

## V2.0.0
Initial module creation
