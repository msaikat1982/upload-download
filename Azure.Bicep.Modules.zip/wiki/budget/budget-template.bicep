// This template creates a GEHA budget that will track the maximum budget allowed within a specified timeframe & will also send out notifications when contraints are met.

targetScope = 'subscription'

/////////////////////////
///REQUIRED PARAMETERS //
/////////////////////////

@description('Used for deployments to make them unique.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
                         
@description ('default subscription example.')
param GEHA407TIO string = 'b02ade0d-cdbe-417c-9469-150000f3ae25'  //Cloud team dev subscription

@description ('Sample deployment for subscription')
param budgets array = [
  {
    scope: string(GEHA407TIO)
    budgetName: 'endDate Test'
    startDate: '2025-09-01T00:00:00Z'
    endDate: ''
    maximumBudget: 3000
    timegrain: 'Quarterly'
    notifications: {
      Actual_Over_90_Percent:{
        enabled: true
        operator: 'GreaterThanOrEqualTo'
        threshold: 90
        thresholdType: 'Actual'
        contactEmails: ['infraplatform@geha.com']
      }
      Forecast_Over_80_Percent: {
        enabled:true
        operator: 'GreaterThanOrEqualTo'
        threshold: 80
        thresholdType: 'Forecasted'
        contactEmails: ['infraplatform@geha.com']    
      }
    }
    }
    {
      scope: string(GEHA407TIO)
      budgetName: 'endDate Test 2'
      startDate: '2025-09-01T00:00:00Z'
      endDate: ''
      maximumBudget: 3000
      timegrain: 'Quarterly'
      notifications: {
        Actual_Over_90_Percent:{
          enabled: true
          operator: 'GreaterThanOrEqualTo'
          threshold: 90
          thresholdType: 'Actual'
          contactEmails: ['infraplatform@geha.com']
        }
        Forecast_Over_80_Percent: {
          enabled:true
          operator: 'GreaterThanOrEqualTo'
          threshold: 80
          thresholdType: 'Forecasted'
          contactEmails: ['infraplatform@geha.com']    
        }
      }
    }
  ]


///////////////////
// CALL MODULE ////
///////////////////


module setbudget '../../modules/budget/budget.bicep' = [for budget in budgets: {
  name: '${replace(budget.budgetName, ' ','')}-${deploymentTimeStamp}'
  scope: subscription(budget.scope)
  params: {
    budgetName: budget.budgetName
    startDate: budget.startDate
    endDate: budget.endDate
    maximumBudget: budget.maximumBudget
    timegrain: budget.timegrain
    notifications: budget.notifications
      
  }
}]
