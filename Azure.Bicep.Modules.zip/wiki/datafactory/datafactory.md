# Data Factory

[Data Factory Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/datafactory/datafactory-template.bicep&version=GBmain)


# Changelog

## V3.0.2
REMOVES support for deploying MANAGED private endpoints.
Managed Private Endpoints should be managed in the Data Factory code repository and not bicep.

## V3.0.1
Adds support for deploying managed private endpoints

// Managed Private Endpoints...

## Note: Managed Private Endpoints

  UPDATE: We do not use Bicep as source control for Managed Private Endpoints in ADF. When ADF is connected to Git, the MPE's in Live Mode will be overwritten by Master.

  Managed Private Endpoints can be managed in the Git repo and parameterized along with the other ADF code.