//////////////////////
// REQUIRED PARAMETERS
//////////////////////

param dataFactoryName string = ''

param location string = ''

param env string = ''

//////////////////////
// OPTIONAL PARAMETERS
//////////////////////

param repoConfiguration object = {}
// Example Object:
// {
//   accountName: ''
//   repositoryName: ''
//   collaborationBranch: ''
//   rootFolder: ''
//   type: ''
//   disablePublish: true
// }

// Specifies additional resource tags
param tags object = {
    
}

// Create System Assigned Managed Identity
param identityType string = 'SystemAssigned'

//////////////////////
// PRIVATE ENDPOINT //
//////////////////////

/*

  To create a Private Endpoint for your Data Factory, pass the full Subnet ID of your subnet from the Azure Portal.

  Example:
  param subnetId string = '/subscriptions/<subscriptionId>/resourceGroups/<resource-group>/providers/Microsoft.Network/virtualNetworks/<vnet-name>/subnets/<subnet-name>'

  Leave 'subnetId' empty (pass an empty string) to NOT create a Private Endpoint

*/

@description('Specifies the full subnet Resource Id for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = '/subscriptions/7807b17a-4cf8-45be-b90b-4e0e18040a3e/resourceGroups/rg-alz-southcentralus-vnet-da-adf-scus-dev-01/providers/Microsoft.Network/virtualNetworks/vnet-da-adf-scus-dev-01/subnets/snet-da-adf-dev-01'

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module dataFactory 'br:gehabicep.azurecr.io/bicep/modules/datafactory:v3.0.2' = {
  name: 'adf-${deploymentTimeStamp}'
  params: {
    dataFactoryName: dataFactoryName
    location: location
    env: env
    tags: tags
    identityType: identityType
    repoConfiguration: repoConfiguration
    subnetId: subnetId
  }
}
