# Data Factory

# Changelog

## V1.0.1
Update default ttl to 5 minutes

## V1.0.0
Initial module