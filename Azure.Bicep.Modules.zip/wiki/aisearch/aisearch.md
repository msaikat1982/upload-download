# AI Search

[AI Search Example Usage]()


# Changelog

# V1.0.4
Updates process for creating private endpoint and dns zones

## V1.0.2
adds new var (customSubDomainName) to resolve issue with private endpoint creation
