//////////////////////
// REQUIRED PARAMETERS
//////////////////////

//Specfies the Key Vault where the Secret is deployed
param keyvaultName string = ''

//Specifies the Secret value. This value is to be referenced from a Variable Group in your pipeline (see readme.md)
//DO NOT declare a secret value here in plain text
param secrets array = [

]

//////////////////////
// OPTIONAL PARAMETERS
//////////////////////

//Specifies additional resource tags. Provide key/value pairs, like, MyTag: 'A new tag value'
param tags object = {
    
}

//////////////
// CALL MODULE
//////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module secret 'br:gehabicep.azurecr.io/bicep/modules/keyvaultsecret:v3.0.0' = {
  name: 'secret-${deploymentTimeStamp}'
  params: {
    keyvaultName: keyvaultName
    secrets: secrets
    tags: tags
  }
}
