//////////////////////
// REQUIRED PARAMETERS
//////////////////////

//Specifies the Azure Region for the Service Bus Namespace. Allowed: 'centralus','eastus','northcentralus','southcentralus'
param location string = ''

//Specifies the Environment for the Service Bus Namespace. Allowed: poc|dev|tst|stg|prd
param env string = ''

@description('Specifies the full subnet Resource Id for deploying a Private Endpoint. Use an empty string for no private endpoints.')
param subnetId string = ''

//////////////////////
// OPTIONAL PARAMETERS
//////////////////////

//Specifies additional resource tags for the Key Vault. Provide key/value pairs, like, Description: 'A new Service Bus Namespace'
param tags object = {
      
}

//////////////
// CALL MODULE
//////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

// Keyvault Params...

// IMPORTANT: If you reference an exising key vault here, you must also reassign any existing Access Policies

param keyVaultName string = '' 
param isAKSintegrated bool = false // 'true' will assign an Access Policy for environment specific AKS Key Vault provider

////////////////////////
// CALL KEYVAULT MODULE - Depends on svcbusnamespace
////////////////////////

module keyvault 'br:gehabicep.azurecr.io/bicep/modules/keyvault:v3.0.0' = {
  name: 'kv-${deploymentTimeStamp}'
  params: {
    keyVaultName: keyVaultName
    location: location
    env: env
    isAKSintegrated: isAKSintegrated
    subnetId: subnetId
    tags: tags
  }
}

//////////////////////////////////////////////
// CALL SECRET MODULE - Depends on keyvault //
//////////////////////////////////////////////

// to use an existing service bus, use the code in this example
// otherwise, reference your servicebus module call for the id, name, and apiversion
resource servicebus 'Microsoft.ServiceBus/namespaces@2023-01-01-preview' existing = {
  name: '[the name of your service bus]'
  scope: resourceGroup('[subscription Id]','[resource group name]')
}

param secretName string = ''

module secret 'br:gehabicep.azurecr.io/bicep/modules/keyvaultsecretservicebus:v2.0.4' = {
  name: 'secret-servicebus-${deploymentTimeStamp}'
  params: {
    serviceBusId: servicebus.id    
    serviceBusApiVersion: servicebus.apiVersion
    keyvaultName: keyvault.outputs.keyvaultResourceName
    secretName: secretName
  }
}
