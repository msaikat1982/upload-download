# Key Vault Secret - ServiceBus

[Key Vault Secret ServiceBus Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/keyvaultsecret/keyvaultsecretservicebus-template.bicep&version=GBmain)


# Changelog

## V2.0.4
Initial module creation
