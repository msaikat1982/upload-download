# Key Vault Secret

## How to use this template:

This template will leverage the keyvaultsecret Bicep module hosted in ACR to deploy a new Secret.

You can copy this template into your own repository and use in a pipeline.

To deploy a new Key Vault Secret using this template, import values from a Variable Group in ADO Pipelines.

## IMPORTANT: Do not commit secret values to git. Do not expose secret values in plain text in this template.

To import a variable from a Variable Group:

First, you must reference your Azure Pipeline Variable Group in your pipeline. This will import your variables for later use...
```yaml
variables:
  - group: your_variable_group_name

## Notes:

[All Secret Properties](https://learn.microsoft.com/en-us/azure/templates/microsoft.keyvault/vaults/secrets?pivots=deployment-language-bicep)

## Variable Group Example Pipeline:
---
trigger: none

stages:
  - template: Azure/Bicep-Stages.yml@templates
    parameters:
      AzureEnvironments: ['dev','test','stage','prod']
      Action: ${{ parameters.Action }}
      devLibraryGroup: [YourLibraryGroup]
      devDeployments:
        AzureARMSvcConn: ${{ variables.AzDO_Svc_Conn_[YourServiceConnection] }}
        deployments:
          - deployment-file: deployments/deployment.bicep
            bicep-parameters-file: deployments/dev.bicepparam

      bicepParameters: 
        - deployment-file: deployments/deployment.bicep
          bicepParameters: |
            --parameters secrets='(
              ("secret1","$(secret1)"),
              ("secret2","$(secret2)")
              )'

[Key Vault Secret Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/keyvaultsecret/keyvaultsecret-template.bicep&version=GBmain)

```

## Passwords with Escape Characters
Password and secrets should be generated with the GEHA standard password generator tool: 
https://passgen.gateway.prd-aks.geha.com

This excludes certain escape characters that get broken when the "bicepParameters" parameter is serialized in the deployment template.

***Excluded special characters:***

Quotation marks: ```"```, ```'```

Backtick: ``` ` ```

Backslash: ```\```

Slash: ```/```

Tilde: ```~```

### Special Characters Workaround
There are situations where avoiding the special characters above in a secret will not be possible, such as private keys or JSON objects.
To get around the limitations above, you can try to Base64 encode your secret, and then add to the library group. Then, at run-time
your application or service will need to Base64 decode the secret before being used.

If this does not work, the fallback would be to manually load the secret into each keyvault instead of using the ADO Bicep Deploy Template 
for just those problematic secrets.

## Miscellaneous

The *readEnvironmentVariable()* is a bicep function that is available in .bicepparam files. It has a few caveats if you decide to use it instead of referencing your
library group secrets in your azure-pipelines.yaml file.
1. If you pull in environment variables from an Azure DevOps library group, you must reference them as all caps in the bicepparam file.
2. If you use the secure button in the ADO library group that hides the value, it is no longer available to this function.


# Changelog

## V3.0.0
Major version change: Moved secrets iterative loop from deployment file into keyvaultsecret module.
Passing 'secrets' parameter in deployment file is all that is required to create multiple secrets from your library group.

## V2.0.0
Initial module creation
