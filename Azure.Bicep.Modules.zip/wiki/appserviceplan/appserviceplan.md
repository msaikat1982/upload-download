# App Service Plan

#[App Service Plan Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/appserviceplan/appserviceplan-template.bicep&version=GBmain)

# Changelog

## V1.0.5
Removed unnecessary SkuTier param. Add conditional for zoneRedundancy since certain SKUs don't support it.

## V1.0.3
Added params for capacity and zone redundancy settings.

## V1.0.2
Adding zoneRedundant: true and remove NorthCentralUS since they do not provide zone redundancy.

## V1.0.1
Removes diagnostic settings since they are managed by Azure Policy.

## V1.0.0
Initial module creation