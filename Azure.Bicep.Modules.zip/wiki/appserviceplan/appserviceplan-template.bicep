//Creates an App Service Plan
//For information on App Service Plan refer to: https://learn.microsoft.com/en-us/azure/app-service/overview-hosting-plans
//An App Service Plan defines a set of compute resources for a web app to run.  Each App Service plan defines:
  //Operating System
  //Region
  //Number of VM instances
  //Size of VM instances
  //Pricing Tier

/////////////////////////
// Required Parameters //
/////////////////////////
 
@description('The name of the App Service Plan')
param name string

@description('The Azure region to deploy the App Service Plan.')
param location string

/////////////////////////
// Optional Parameters //
/////////////////////////

@description('Azure resource tags provided as key/value object.')
param tags object = {}

/////////////////////////////////
// App Service Plan Parameters //
/////////////////////////////////

@description('The type of service and its capabilities.')
var kind = {
	Windows: 'app'
	Linux: 'linux'
  Consumption: 'FunctionApp'
	PremiumConsumption: 'elastic'
	xenon: 'xenon'
	reserved: 'true'
}

@description('The SKU name of the App Service Plan.')
param skuName string

@description('The SKU tier of the App Service Plan.')
param skuTier string

/////////////////
// Module Call //
/////////////////

param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')
module appserviceplan 'br:gehabicep.azurecr.io/bicep/modules/appserviceplan:v1.0.1' = {
  name: 'appserviceplan-${deploymentTimeStamp}'
  params: {
    name: name
    location: location
    tags: tags
    skuName: skuName
    skuTier: skuTier
    kind: kind.Linux
  }
}
