// Creates an Azure Container Registry

////////////////
// Parameters //
////////////////

@description('Azure region of the deployment')
param location string

@description('Container registry name')
param containerRegistryName string

@description('Azure Resource Tags for the new resources.')
param tags object

@description('A timestamp for naming unique deployments.')
param deploymentTimeStamp string = utcNow('yyyyMMddHHmmss')

module containerRegistry '../../modules/containerregistry/containerregistry.bicep' = {
  name: 'acr-${deploymentTimeStamp}'
  params: {
    location: location
    containerRegistryName: containerRegistryName
    tags: tags
  }
}
