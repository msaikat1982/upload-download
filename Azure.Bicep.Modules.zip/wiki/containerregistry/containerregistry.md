# Container Registry

[Data Factory Example Usage](https://dev.azure.com/geha/TIO/_git/Azure.Bicep.Modules?path=/wiki/containerregistry/containerregistry-template.bicep&version=GBmain)


# Changelog

## V2.0.0
Initial module creation