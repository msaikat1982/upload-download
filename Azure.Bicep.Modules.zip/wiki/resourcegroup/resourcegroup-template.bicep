targetScope = 'subscription'

///////////////////////////////
// RESOURCE GROUP DEPLOYMENT //
///////////////////////////////

@description('Azure Region to deploy Storage Account')
@allowed(['centralus','eastus','northcentralus','southcentralus'])
param location string

@description('The name of the Resource Group where new resources will be deployed.')
param resourceGroupName string = ''

@description('The Resource Group where new resources will be deployed.')
resource rg 'Microsoft.Resources/resourceGroups@2025-04-01' = {
  name: resourceGroupName
  location: location
}
