# Scheduled Query Rules

[Documentation](https://learn.microsoft.com/en-us/azure/templates/microsoft.insights/scheduledqueryrules?pivots=deployment-language-bicep)

# Changelog

## V1.0.0
Initial module