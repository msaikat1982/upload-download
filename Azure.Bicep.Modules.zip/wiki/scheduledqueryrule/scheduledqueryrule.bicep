@description('The name of the api for which you are creating the alert')
param apiName string = ''

@description('The environment of the api')
param env string = ''

@description('http reponse codes you intend to alert on')
var codes = [] // '400', '401', '500', etc.

@description('The name of the Action Group you want to trigger')
param actionGroup string = ''

@description('Details of the Log Analytics Workspace to query')
param logAnalyticsWorkspaceDetails object = {
  location: '' // azure region of the log analytics workspace
  subscriptionId: '' // ID of subscription that hosts the log analytics workspace
  resourceGroup: '' // resource group that hosts the log analytics workspace
  workspaceName: '' // name of the log anayltics workspace
}

@description('Threshold of returned rows to alert on')
param threshold int = 0

@description('Operator on threshold')
param operator string = 'GreaterThan'

@description('Evaluation frequency')
param evaluationFrequency string = 'PT5M' //5 minutes

@description('Window size')
param windowSize string = 'PT5M' // 5 minutes

@description('Aggregation type')
param timeAggregation string = 'Count'

@description('Alert severity')
param severity int = 3

@description('Auto mitigate')
param autoMitigate bool = false

@description('A single-line kusto query')
param kustoQuery string = '' //'AppRequests | where TimeGenerated > ago(1h) | where Properties[\'API Name\'] == "${apiName}" | where toint(ResultCode) == "${code}" | where Url matches regex "api.geha.com"'

module alerts 'br:gehabicep.azurecr.io/bicep/modules/scheduledqueryrule:v1.0.0' = [for code in codes: {
  name: 'alert-${apiName}-${env}-${code}'
  params: {
    alertRuleDetails: {
      logAnalyticsWorkspaceLocation: logAnalyticsWorkspaceDetails.location
      logAnalyticsWorkspaceSubId: logAnalyticsWorkspaceDetails.subscriptionId
      logAnalyticsWorkspaceRg: logAnalyticsWorkspaceDetails.resourceGroup
      logAnalyticsWorkspaceName: logAnalyticsWorkspaceDetails.workspaceName
      actionGroupName: actionGroup
      alertRuleName: '${apiName}-${env}-${code}'
      description: 'Alert on ${apiName} ${env}: Response code ${code}'
      displayName: '${apiName}-${env}-${code}'
      kind: 'LogAlert'
      threshold: threshold
      evaluationFrequency: evaluationFrequency
      windowSize: windowSize
      timeAggregation: timeAggregation
      operator: operator
      severity: severity
      autoMitigate: autoMitigate
      kustoQuery: kustoQuery
    }
  }
}]
